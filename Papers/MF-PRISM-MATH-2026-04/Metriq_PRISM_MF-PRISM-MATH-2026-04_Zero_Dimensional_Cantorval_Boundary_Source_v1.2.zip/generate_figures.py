#!/usr/bin/env python3
"""Generate formula-derived figures and cover artwork for MF-PRISM-MATH-2026-04.

The artwork is generated from the mixed-radix construction in the manuscript.
No stock or generative image is used.
"""
from __future__ import annotations

from pathlib import Path
from typing import Literal
import math

import mpmath as mp
import numpy as np
import matplotlib.pyplot as plt
plt.rcParams["pdf.fonttype"] = 42
plt.rcParams["ps.fonttype"] = 42
from matplotlib.collections import LineCollection
from PIL import Image, ImageDraw, ImageFilter

ROOT = Path(__file__).resolve().parent
FIG = ROOT / "figures"
FIG.mkdir(exist_ok=True)
mp.mp.dps = 80


def base(n: int) -> int:
    return 2 * n + 2


def Q(n: int) -> int:
    q = 1
    for k in range(1, n + 1):
        q *= base(k)
    return q


def digits(n: int) -> tuple[int, ...]:
    # Subset sums of (3, 2, ..., 2) with n copies of 2.
    return tuple(sorted(set(range(0, 2 * n + 1, 2)) | set(range(3, 2 * n + 4, 2))))


def all_prefixes(level: int) -> np.ndarray:
    vals = np.asarray([0.0])
    for n in range(1, level + 1):
        q = Q(n)
        ds = np.asarray(digits(n), dtype=float) / q
        vals = (vals[:, None] + ds[None, :]).reshape(-1)
    return vals


def A_normalized(n: int) -> mp.mpf:
    """A_n = sum_{k=n}^inf 1/(b_n...b_k)."""
    term = mp.mpf(1) / base(n)
    total = term
    k = n
    while abs(term) > mp.mpf("1e-75"):
        k += 1
        term /= base(k)
        total += term
    return total


def S_normalized(n: int) -> mp.mpf:
    return 1 + 2 * A_normalized(n)


def total_sum() -> mp.mpf:
    return 4 * mp.sqrt(mp.e) - 5


def actual_tail(level: int) -> float:
    # Tail after block level = S_{level+1}/Q_level.
    return float(S_normalized(level + 1) / Q(level))


def merge_intervals(intervals: list[tuple[float, float]], tol: float = 1e-14) -> list[tuple[float, float]]:
    intervals.sort()
    merged: list[list[float]] = []
    for lo, hi in intervals:
        if not merged or lo > merged[-1][1] + tol:
            merged.append([lo, hi])
        else:
            merged[-1][1] = max(merged[-1][1], hi)
    return [(lo, hi) for lo, hi in merged]


State = Literal["L", "U"]


def boundary_cover(level: int) -> list[tuple[float, float, State]]:
    """Return the 2*3^level state cylinders covering the boundary.

    A record is (prefix, offset, state), represented here as actual interval
    endpoints after the level digits. The tail state at level+1 has hull
    [0, 2A] for L and [1, 1+2A] for U.
    """
    nodes: list[tuple[float, State]] = [(0.0, "L"), (0.0, "U")]
    for n in range(1, level + 1):
        q = Q(n)
        b = base(n)
        nxt: list[tuple[float, State]] = []
        for prefix, state in nodes:
            if state == "L":
                nxt.extend([
                    (prefix + 0 / q, "L"),
                    (prefix + 0 / q, "U"),
                    (prefix + 2 / q, "L"),
                ])
            else:
                nxt.extend([
                    (prefix + (b + 1) / q, "U"),
                    (prefix + (b + 1) / q, "L"),
                    (prefix + (b - 1) / q, "U"),
                ])
        nodes = nxt

    qn = Q(level) if level else 1
    a = float(A_normalized(level + 1))
    width = 2 * a / qn
    out: list[tuple[float, float, State]] = []
    for prefix, state in nodes:
        offset = 0.0 if state == "L" else 1.0 / qn
        lo = prefix + offset
        out.append((lo, lo + width, state))
    return out


def make_outer_approximations() -> None:
    levels = [1, 2, 3, 4, 5]
    total = float(total_sum())
    fig, ax = plt.subplots(figsize=(11.4, 4.8))
    for idx, n in enumerate(levels):
        y = len(levels) - idx
        starts = all_prefixes(n)
        tail = actual_tail(n)
        merged = merge_intervals([(float(x), float(x + tail)) for x in starts])
        segments = [((lo / total, y), (hi / total, y)) for lo, hi in merged]
        ax.add_collection(LineCollection(segments, linewidths=5.9, alpha=0.93, capstyle="butt"))
        ax.text(-0.025, y, rf"$U_{n}$", ha="right", va="center", fontsize=10)
        ax.text(1.018, y, f"{len(merged):,} components", ha="left", va="center", fontsize=9)
    ax.set_xlim(-0.10, 1.19)
    ax.set_ylim(0.35, len(levels) + 0.65)
    ax.set_yticks([])
    ax.set_xticks([0, 0.25, 0.5, 0.75, 1.0])
    ax.set_xticklabels(["0", "0.25", "0.50", "0.75", "1"], fontsize=9)
    ax.set_xlabel("normalized position in the achievement set", fontsize=10)
    for spine in ["top", "right", "left"]:
        ax.spines[spine].set_visible(False)
    ax.grid(axis="x", alpha=0.18, linewidth=0.5)
    fig.tight_layout(pad=0.8)
    fig.savefig(FIG / "outer_approximations.pdf", bbox_inches="tight")
    fig.savefig(FIG / "outer_approximations.png", dpi=260, bbox_inches="tight")
    plt.close(fig)


def make_boundary_covers() -> None:
    levels = [0, 1, 2, 3, 4, 5, 6]
    total = float(total_sum())
    fig, ax = plt.subplots(figsize=(11.4, 5.3))
    for idx, n in enumerate(levels):
        y = len(levels) - idx
        intervals = boundary_cover(n)
        segments = [((lo / total, y), (hi / total, y)) for lo, hi, _ in intervals]
        lw = max(0.34, 5.0 - 0.62 * n)
        ax.add_collection(LineCollection(segments, linewidths=lw, alpha=0.93, capstyle="butt"))
        ax.text(-0.025, y, rf"$\mathcal{{B}}_{n}$", ha="right", va="center", fontsize=10)
        ax.text(1.018, y, f"{len(intervals):,} cylinders", ha="left", va="center", fontsize=9)
    ax.set_xlim(-0.10, 1.19)
    ax.set_ylim(0.35, len(levels) + 0.65)
    ax.set_yticks([])
    ax.set_xticks([0, 0.25, 0.5, 0.75, 1.0])
    ax.set_xticklabels(["0", "0.25", "0.50", "0.75", "1"], fontsize=9)
    ax.set_xlabel("normalized boundary-cover position", fontsize=10)
    for spine in ["top", "right", "left"]:
        ax.spines[spine].set_visible(False)
    ax.grid(axis="x", alpha=0.18, linewidth=0.5)
    fig.tight_layout(pad=0.8)
    fig.savefig(FIG / "boundary_covers.pdf", bbox_inches="tight")
    fig.savefig(FIG / "boundary_covers.png", dpi=260, bbox_inches="tight")
    plt.close(fig)


def add_glow(base_img: Image.Image, layer: Image.Image,
             radii: tuple[int, ...] = (8, 22, 55),
             opacities: tuple[float, ...] = (0.45, 0.18, 0.07)) -> Image.Image:
    out = base_img.copy()
    for radius, opacity in zip(radii, opacities):
        blurred = layer.filter(ImageFilter.GaussianBlur(radius))
        alpha = blurred.getchannel("A").point(lambda p: int(p * opacity))
        blurred.putalpha(alpha)
        out = Image.alpha_composite(out, blurred)
    return Image.alpha_composite(out, layer)


def make_cover_art() -> None:
    W, H = 2550, 3300
    yy, xx = np.mgrid[0:H, 0:W]

    top = np.array([7, 10, 12], dtype=float)
    bottom = np.array([2, 27, 29], dtype=float)
    t = (yy / H)[:, :, None]
    arr = top * (1 - t) + bottom * t
    radial = np.exp(-(((xx - 1780) / 980) ** 2 + ((yy - 2050) / 1200) ** 2))[:, :, None]
    arr += radial * np.array([0, 37, 31], dtype=float)
    blue = np.exp(-(((xx - 420) / 800) ** 2 + ((yy - 2500) / 900) ** 2))[:, :, None]
    arr += blue * np.array([0, 10, 36], dtype=float)
    arr = np.clip(arr, 0, 255).astype(np.uint8)
    img = Image.fromarray(arr, mode="RGB").convert("RGBA")

    grid = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gd = ImageDraw.Draw(grid)
    for x in range(0, W, 75):
        gd.line((x, 0, x, H), fill=(198, 245, 221, 8), width=1)
    for y in range(0, H, 75):
        gd.line((0, y, W, y), fill=(198, 245, 221, 8), width=1)
    img = Image.alpha_composite(img, grid)

    # Monumental geometric zero: the result's dimension, not a typographic glyph.
    zero = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    zd = ImageDraw.Draw(zero)
    outer = (1640, 300, 2290, 1540)
    inner = (1815, 485, 2115, 1355)
    zd.rounded_rectangle(outer, radius=300, fill=(25, 114, 220, 28), outline=(42, 209, 137, 45), width=5)
    zd.rounded_rectangle(inner, radius=145, fill=(8, 15, 17, 210), outline=(198, 245, 221, 24), width=3)
    img = Image.alpha_composite(img, zero)

    # Exact finite-level boundary covers: 2*3^N components, with factorial scale collapse.
    total = float(total_sum())
    x0, x1 = 250, 2300
    band = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    bd = ImageDraw.Draw(band)
    y_positions = [1590, 1745, 1900, 2055, 2210, 2365, 2520]
    colors = [
        (198, 245, 221, 235),
        (42, 209, 137, 225),
        (6, 162, 105, 220),
        (12, 141, 143, 210),
        (25, 114, 220, 205),
        (42, 209, 137, 190),
        (198, 245, 221, 165),
    ]
    for n, y, color in zip(range(0, 7), y_positions, colors):
        intervals = boundary_cover(n)
        lw = max(1, 10 - n)
        for lo, hi, _ in intervals:
            xa = int(round(x0 + (lo / total) * (x1 - x0)))
            xb = int(round(x0 + (hi / total) * (x1 - x0)))
            bd.line((xa, y, max(xa + 1, xb), y), fill=color, width=lw)
        bd.line((x0 - 30, y, x0 - 8, y), fill=(198, 245, 221, 125), width=2)
    img = add_glow(img, band)

    # Exact central interval [2A_1,1], displayed as a solid luminous bar.
    a1 = float(2 * A_normalized(1))
    central = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    cd = ImageDraw.Draw(central)
    cy = 2768
    ca = int(round(x0 + (a1 / total) * (x1 - x0)))
    cb = int(round(x0 + (1.0 / total) * (x1 - x0)))
    cd.line((ca, cy, cb, cy), fill=(247, 250, 249, 235), width=11)
    cd.line((ca, cy - 27, ca, cy + 27), fill=(42, 209, 137, 225), width=3)
    cd.line((cb, cy - 27, cb, cy + 27), fill=(42, 209, 137, 225), width=3)
    img = add_glow(img, central, radii=(5, 16), opacities=(0.38, 0.13))

    # Particles sampled from the level-7 boundary cover midpoints.
    intervals = boundary_cover(7)
    mids = np.asarray([(lo + hi) / 2 for lo, hi, _ in intervals])
    rng = np.random.default_rng(20260715)
    particles = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    pd = ImageDraw.Draw(particles)
    sample_idx = rng.choice(len(mids), size=min(4000, len(mids)), replace=False)
    for i in sample_idx:
        px = int(round(x0 + (mids[i] / total) * (x1 - x0)))
        py = int(round(2400 + rng.normal(0, 175)))
        radius = 1 if rng.random() < 0.94 else 2
        alpha = int(rng.integers(20, 78))
        pd.ellipse((px - radius, py - radius, px + radius, py + radius), fill=(198, 245, 221, alpha))
    img = Image.alpha_composite(img, particles)

    # Vignette for strong cover typography contrast.
    edge = np.minimum.reduce([xx / 360, (W - 1 - xx) / 360, yy / 430, (H - 1 - yy) / 430])
    edge = np.clip(edge, 0, 1)
    alpha = ((1 - edge) * 148).astype(np.uint8)
    vignette = Image.fromarray(
        np.dstack([np.zeros_like(alpha), np.zeros_like(alpha), np.zeros_like(alpha), alpha]),
        "RGBA",
    )
    img = Image.alpha_composite(img, vignette)
    img.convert("RGB").save(FIG / "cover_art.png", quality=96, dpi=(300, 300))


if __name__ == "__main__":
    make_outer_approximations()
    make_boundary_covers()
    make_cover_art()
    print(f"Generated figures in {FIG}")
