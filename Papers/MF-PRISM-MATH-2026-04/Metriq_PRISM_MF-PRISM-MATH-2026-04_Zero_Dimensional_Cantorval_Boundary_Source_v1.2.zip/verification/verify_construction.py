#!/usr/bin/env python3
"""Exact and high-precision checks for MF-PRISM-MATH-2026-04.

The manuscript proof is analytic. This script checks finite structural instances,
closed-form identities, and asymptotic diagnostics; it is not a substitute for proof.
"""
from __future__ import annotations

from fractions import Fraction
from itertools import product
from math import factorial, lgamma, log, log10
import mpmath as mp

mp.mp.dps = 100


def base(n: int) -> int:
    return 2 * n + 2


def Q(n: int) -> int:
    return 2**n * factorial(n + 1)


def digits(n: int) -> tuple[int, ...]:
    return tuple(sorted(set(range(0, 2 * n + 1, 2)) | set(range(3, 2 * n + 4, 2))))


def block_total(n: int) -> Fraction:
    return Fraction(2 * n + 3, Q(n))


def A_normalized(n: int, cutoff: int = 400) -> mp.mpf:
    term = mp.mpf(1) / base(n)
    total = term
    k = n
    for _ in range(cutoff):
        k += 1
        term /= base(k)
        total += term
        if abs(term) < mp.mpf("1e-90"):
            break
    return total


def S_normalized(n: int) -> mp.mpf:
    return 1 + 2 * A_normalized(n)


def verify_closed_form() -> None:
    a1 = mp.nsum(lambda k: 1 / (2**k * mp.factorial(k + 1)), [1, mp.inf])
    assert mp.almosteq(a1, 2 * mp.sqrt(mp.e) - 3)
    total = mp.nsum(lambda k: (2 * k + 3) / (2**k * mp.factorial(k + 1)), [1, mp.inf])
    assert mp.almosteq(total, 4 * mp.sqrt(mp.e) - 5)
    assert mp.almosteq(total, 1 + 2 * a1)


def verify_residue_system(max_n: int = 20) -> None:
    for n in range(1, max_n + 1):
        b = base(n)
        D = digits(n)
        assert len(D) == b
        assert D == tuple([0] + list(range(2, b)) + [b + 1])
        assert {d % b for d in D} == set(range(b))
        assert all((base(n) + 1 - d) in D for d in D)


def verify_monotone_sequence(max_n: int = 200) -> None:
    for n in range(1, max_n + 1):
        large = Fraction(3, Q(n))
        small = Fraction(2, Q(n))
        assert large > small > 0
        if n < max_n:
            next_large = Fraction(3, Q(n + 1))
            assert small > next_large


def prefix_data(n0: int, N: int) -> tuple[int, int, list[int]]:
    P = 1
    for k in range(n0, N + 1):
        P *= base(k)
    weights = {k: P // __import__("math").prod(base(j) for j in range(n0, k + 1)) for k in range(n0, N + 1)}
    vals = []
    for word in product(*(digits(k) for k in range(n0, N + 1))):
        vals.append(sum(word[k - n0] * weights[k] for k in range(n0, N + 1)))
    C = 2 * sum(weights.values())
    return P, C, vals


def verify_mixed_radix(max_N: int = 5) -> None:
    for N in range(1, max_N + 1):
        P, C, vals = prefix_data(1, N)
        assert len(vals) == P
        assert len(set(vals)) == P
        assert {v % P for v in vals} == set(range(P))
        assert max(vals) == P - 1 + C
        assert C < P
        value_set = set(vals)
        assert all(r in value_set for r in range(C, P))


def verify_tail_and_gap_inequalities(max_n: int = 100) -> None:
    for n in range(1, max_n + 1):
        A = A_normalized(n)
        S = 1 + 2 * A
        assert A < mp.mpf("0.5")
        assert S < 2
        assert 2 * A < 1
        # Recurrence A_n=(1+A_{n+1})/b_n.
        assert mp.almosteq(A, (1 + A_normalized(n + 1)) / base(n), rel_eps=mp.mpf("1e-80"), abs_eps=mp.mpf("1e-80"))


def merge_count(level: int) -> int:
    prefixes = [mp.mpf("0")]
    for n in range(1, level + 1):
        q = mp.mpf(Q(n))
        prefixes = [x + mp.mpf(d) / q for x in prefixes for d in digits(n)]
    tail = S_normalized(level + 1) / Q(level)
    intervals = sorted((x, x + tail) for x in prefixes)
    merged: list[list[mp.mpf]] = []
    for lo, hi in intervals:
        if not merged or lo > merged[-1][1]:
            merged.append([lo, hi])
        else:
            merged[-1][1] = max(merged[-1][1], hi)
    return len(merged)


def verify_outer_component_counts(max_n: int = 5) -> None:
    for n in range(1, max_n + 1):
        assert merge_count(n) == 3**n


def verify_boundary_branching(max_n: int = 12) -> None:
    count = 2
    for n in range(0, max_n + 1):
        assert count == 2 * 3**n
        count *= 3


def dimension_diagnostics() -> list[tuple[int, float, float]]:
    """Return asymptotic cover diagnostics without floating-point underflow.

    The third column is log10 of the s=0.1 Hausdorff cover cost
        2*3^n * (2/(3*Q_n))^0.1.
    A negative value therefore certifies that the displayed upper bound is < 1.
    """
    out = []
    for n in [1, 2, 3, 5, 10, 20, 50, 100, 500, 1_000, 10_000, 100_000]:
        log_q = n * log(2) + lgamma(n + 2)
        log_count = log(2) + n * log(3)
        ratio = log_count / log_q
        s = 0.1
        log10_cover = (log_count + s * (log(2 / 3) - log_q)) / log(10)
        out.append((n, ratio, log10_cover))
    return out


def main() -> None:
    verify_closed_form()
    verify_residue_system()
    verify_monotone_sequence()
    verify_mixed_radix()
    verify_tail_and_gap_inequalities()
    verify_outer_component_counts()
    verify_boundary_branching()

    print("All finite structural and high-precision checks passed.")
    print("\nFirst blocks:")
    print(" n   b_n       Q_n    block numerators                    D_n")
    for n in range(1, 7):
        block = "(3," + ",".join(["2"] * n) + ")"
        print(f"{n:2d} {base(n):5d} {Q(n):10d}  {block:<35s} {digits(n)}")

    print("\nClosed forms:")
    print(f"A_1 = 2*sqrt(e)-3 = {float(2 * mp.sqrt(mp.e) - 3):.15f}")
    print(f"sum E = 4*sqrt(e)-5 = {float(4 * mp.sqrt(mp.e) - 5):.15f}")
    print(f"central interval = [{float(4 * mp.sqrt(mp.e) - 6):.15f}, 1]")

    print("\nFinite outer-approximation component counts:")
    for n in range(1, 6):
        print(f"U_{n}: {merge_count(n)} = 3^{n}")

    print("\nBoundary cover diagnostics:")
    print("      n    log(2*3^n)/log(Q_n)    log10(s=0.1 cover cost)")
    for n, ratio, log10_cover in dimension_diagnostics():
        print(f"{n:7,d} {ratio:25.15f} {log10_cover:27.12f}")


if __name__ == "__main__":
    main()
