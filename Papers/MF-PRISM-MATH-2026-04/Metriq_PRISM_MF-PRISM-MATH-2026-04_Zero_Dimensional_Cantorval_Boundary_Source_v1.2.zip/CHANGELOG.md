# Changelog - MF-PRISM-MATH-2026-04

## Version 1.2 - 18 July 2026

Metriq PRISM Laboratory edition; updated cover and masthead, institutional disclaimer, release metadata, licensing, checksums, and package organization. No mathematical claim was changed.

## Version 1.0 - 15 July 2026

Initial candidate preprint; subsequent internal audit found no mathematical correction required.

## Version 1.2 - 2026-07-18

- Migrated identifier from `MF-MATH-2026-04` to `MF-PRISM-MATH-2026-04`.
- Added candidate-stage contributor, ORCID, correspondence, funding, conflicts, licensing, DOI, and predecessor metadata.
- Removed an unnecessary unproved nesting assertion and strengthened the explicit treatment of central boundary endpoints.
- Rebuilt and revalidated the PDF and source package.
