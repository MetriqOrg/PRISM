# Source Problem and Citation

**Source:** Achievement Sets - Current Results and Open Problems  
**URL:** https://arxiv.org/abs/2512.17285

## Problem context

Problem 23(ii) asks whether an achievable Cantorval can have boundary of Hausdorff dimension zero.

## Reviewer task

Confirm the exact source wording, intended scope, and whether the candidate theorem actually answers that problem or conjecture. Search for equivalent prior formulations and results.
