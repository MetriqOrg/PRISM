# Verification Scope

## What was checked internally

- All three finite certificates were checked independently by dynamic polynomial multiplication and exhaustive subset enumeration.
- The coefficient histograms sum to 2^N in each case, providing a global consistency check.
- The ternary tail has unique representations because each term exceeds the remaining tail.
- Distinct integer prefix sums produce disjoint translates because the tail lies in an interval of length 1/2.
- A finite disjoint union of Cantor copies is compact, perfect, and totally disconnected, so the infinite realization is a Cantor set.
- No fatal defect was identified. The main external questions are whether the blank table entries were interpreted correctly and whether the witnesses were previously known.

## What the computation does not establish

- novelty or publication priority;
- correctness of unencoded infinite arguments;
- correctness of the source-problem interpretation;
- applicability of external classification or dimension theorems unless those hypotheses are separately checked;
- journal-level peer review.

## Included verifier

`Verification/verify_all_certificates.py`

The rerun output is included in `Verification/internal_rerun_output.txt`.
