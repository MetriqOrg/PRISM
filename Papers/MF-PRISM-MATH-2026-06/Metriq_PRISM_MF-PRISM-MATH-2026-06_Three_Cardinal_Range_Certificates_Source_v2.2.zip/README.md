# MF-PRISM-MATH-2026-06 - Finite Certificates for Three Unresolved Cardinal-Function Ranges

**Canonical candidate version:** 2.2  
**Release date:** 18 July 2026  
**Organizational creator and issuer:** Metriq PRISM Laboratory, Metriq Foundation, Inc.  
**Corresponding contributor:** Daniel H. Jeffery, Research Director  
**ORCID:** https://orcid.org/0009-0001-1200-6042  
**Correspondence:** prism@metriq.org  
**Status:** Internally audited candidate preprint; independent specialist review outstanding  
**Internal decision:** PROCEED - HIGHEST CURRENT CONFIDENCE  
**Risk:** Low to moderate  
**DOI:** 10.5281/zenodo.21434632

## Files

- `Metriq_PRISM_MF-PRISM-MATH-2026-06_Three_Cardinal_Range_Certificates_v2.2.pdf` - corrected institutional candidate edition
- `Metriq_PRISM_MF-PRISM-MATH-2026-06_Three_Cardinal_Range_Certificates_Cover_v2.2.png` - 300-dpi cover image
- `Metriq_PRISM_MF-PRISM-MATH-2026-06_Three_Cardinal_Range_Certificates_Source_v2.2.zip` - complete LuaLaTeX and reproducibility package
- `Metriq_PRISM_MF-PRISM-MATH-2026-06_Reviewer_Packet_v2.2.zip` - standalone external-review packet
- `CITATION.cff` - paper-specific citation metadata
- `zenodo.json` - Zenodo deposit metadata draft
- `PREDECESSOR_RECORD.md` - identifier and version migration record
- `CORRECTIONS_IMPLEMENTED.md` - changes made in this candidate version
- `SHA256SUMS.txt` - release checksums

## Identifier history

`MF-PRISM-MATH-2026-06` Version 2.2 is the canonical successor to `MF-MATH-2026-06` Version 2.1. The historical release remains preserved and citable for provenance; the identifier migration does not reset the original publication chronology.

## Creator and contributor

This candidate edition identifies Metriq PRISM Laboratory as organizational creator and issuer and Daniel H. Jeffery as Research Director and corresponding contributor.

## Review status

Made explicit that the cardinal-function range is taken over attained sums, equivalently positive generating-polynomial coefficients. Independent verification, criticism, replication, and identification of errors are expressly invited.

## Preferred candidate-edition citation

Metriq PRISM Laboratory. *Finite Certificates for Three Unresolved Cardinal-Function Ranges*. MF-PRISM-MATH-2026-06, Version 2.2, 18 July 2026. Corresponding contributor: Daniel H. Jeffery. DOI: 10.5281/zenodo.21434632.
