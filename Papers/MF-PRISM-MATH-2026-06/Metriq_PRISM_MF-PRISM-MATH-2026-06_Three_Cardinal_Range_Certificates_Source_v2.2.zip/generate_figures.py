#!/usr/bin/env python3
"""Generate exact figures and cover artwork for MF-PRISM-MATH-2026-06 v2.1."""
from __future__ import annotations

from collections import Counter
from pathlib import Path
import math
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyBboxPatch
from PIL import Image, ImageDraw, ImageFilter

plt.rcParams["pdf.fonttype"] = 42
plt.rcParams["ps.fonttype"] = 42

ROOT = Path(__file__).resolve().parent
FIG = ROOT / "figures"
FIG.mkdir(exist_ok=True)

MINT = "#C6F5DD"
SIGNAL = "#2AD189"
EMERALD = "#06A269"
TEAL = "#045B5D"
TEAL_LIGHT = "#0C8D8F"
BLUE = "#1972DC"
CHARCOAL = "#333333"
NEARBLACK = "#0B0D0E"
OFFWHITE = "#F7FAF9"
MUTED = "#5F6B6B"
BORDER = "#D6E2DE"
WARNING = "#B36B00"

A = (1, 2, 2, 3, 3)
B = (1, 1, 2, 2, 3, 6)
C = (2, 5, 6, 9, 10, 11, 13)


def counts(seq: tuple[int, ...]) -> list[int]:
    c: Counter[int] = Counter()
    for mask in range(1 << len(seq)):
        c[sum(seq[i] for i in range(len(seq)) if (mask >> i) & 1)] += 1
    return [c[i] for i in range(sum(seq) + 1)]


CA, CB, CC = counts(A), counts(B), counts(C)

# ---------------------------------------------------------------------------
# Figure 1: three exact multiplicity spectra.
# ---------------------------------------------------------------------------
fig = plt.figure(figsize=(10.8, 9.1), facecolor="white")
gs = fig.add_gridspec(3, 1, hspace=0.60)
panels = [
    (fig.add_subplot(gs[0, 0]), CA, A, "{1,2,3,4,5}", "Certificate A", SIGNAL),
    (fig.add_subplot(gs[1, 0]), CB, B, "{1,2,3,5,6}", "Certificate B", BLUE),
    (fig.add_subplot(gs[2, 0]), CC, C, "{1,3,4,5}", "Certificate C", TEAL_LIGHT),
]
for ax, vals, seq, target, label, accent in panels:
    xs = np.arange(len(vals))
    positive = np.array(vals) > 0
    ax.bar(xs[positive], np.array(vals)[positive], width=0.72, color=accent,
           edgecolor=TEAL, linewidth=0.55, zorder=2)
    if not np.all(positive):
        for x in xs[~positive]:
            ax.plot([x - 0.26, x + 0.26], [0.13, 0.13], color=WARNING, linewidth=1.4, zorder=3)
    ax.plot(xs, vals, color=TEAL, linewidth=0.8, marker="o", markersize=2.3, zorder=3)
    if len(vals) <= 18:
        for x, y in zip(xs, vals):
            ax.text(x, y + 0.12, str(y), ha="center", va="bottom", fontsize=7.8, color=CHARCOAL)
    if label == "Certificate C":
        ax.axhline(2, color=WARNING, linewidth=0.9, linestyle=(0, (5, 4)))
        ax.text(len(vals) - 1, 2.10, "multiplicity 2 absent", ha="right", va="bottom",
                color=WARNING, fontsize=8.2, fontweight="bold")
    ax.set_xlim(-0.7, len(vals) - 0.3)
    ax.set_ylim(0, 6.85)
    ax.set_yticks(range(0, 7))
    step = 1 if len(vals) <= 18 else 4
    ax.set_xticks(xs[::step])
    ax.grid(axis="y", alpha=0.17, linewidth=0.65)
    ax.spines[["top", "right"]].set_visible(False)
    ax.spines[["left", "bottom"]].set_color(BORDER)
    ax.tick_params(colors=MUTED, labelsize=7.5)
    ax.set_ylabel("representations", color=CHARCOAL, fontsize=8.8)
    ax.set_xlabel("subset sum", color=CHARCOAL, fontsize=8.8)
    ax.set_title(
        f"{label}: x = ({', '.join(map(str, seq))})  positive coefficient range = {target}",
        loc="left", fontsize=10.3, fontweight="bold", color=CHARCOAL, pad=7,
    )
fig.suptitle("Exact subset-sum multiplicity spectra", x=0.085, y=0.995,
             ha="left", fontsize=15.5, fontweight="bold", color=CHARCOAL)
fig.savefig(FIG / "multiplicity_spectra.pdf", bbox_inches="tight")
fig.savefig(FIG / "multiplicity_spectra.png", dpi=250, bbox_inches="tight")
plt.close(fig)

# ---------------------------------------------------------------------------
# Figure 2: common Cantorization mechanism, sampled across all certificates.
# ---------------------------------------------------------------------------
def cantor_intervals(depth: int) -> list[tuple[float, float]]:
    intervals = [(0.0, 0.5)]
    for _ in range(depth):
        nxt: list[tuple[float, float]] = []
        for a, b in intervals:
            length = b - a
            nxt.append((a, a + length / 3))
            nxt.append((b - length / 3, b))
        intervals = nxt
    return intervals

samples = [
    ("A", 0, 1, SIGNAL),
    ("A", 5, 5, SIGNAL),
    ("B", 6, 6, BLUE),
    ("C", 11, 3, TEAL_LIGHT),
    ("C", 21, 4, TEAL_LIGHT),
    ("C", 24, 5, TEAL_LIGHT),
]
fig, axes = plt.subplots(1, 6, figsize=(11.2, 4.15), facecolor="white")
for ax, (cert, s, multiplicity, accent) in zip(axes, samples):
    card = FancyBboxPatch((-0.06, -0.45), 0.64, 1.72,
                          boxstyle="round,pad=0.02,rounding_size=0.025",
                          facecolor=OFFWHITE, edgecolor=BORDER, linewidth=0.8,
                          transform=ax.transData, clip_on=False, zorder=0)
    ax.add_patch(card)
    for depth in range(0, 6):
        y = 0.92 - depth * 0.19
        for a, b in cantor_intervals(depth):
            ax.add_patch(Rectangle((a, y), b - a, 0.075, facecolor=accent,
                                   edgecolor=TEAL, linewidth=0.24))
    ax.text(0.25, 1.18, rf"certificate {cert}", ha="center", va="center",
            fontsize=8.2, color=MUTED, fontweight="bold")
    ax.text(0.25, 1.04, rf"$s={s}$", ha="center", va="center",
            fontsize=9.0, color=CHARCOAL, fontweight="bold")
    ax.text(0.25, -0.29, rf"$f(s)={multiplicity}$", ha="center", va="center",
            fontsize=10.8, color=TEAL, fontweight="bold")
    ax.set_xlim(-0.08, 0.58)
    ax.set_ylim(-0.48, 1.32)
    ax.axis("off")
fig.suptitle("Cantor extension preserves every finite-prefix multiplicity", x=0.055, y=1.05,
             ha="left", fontsize=14.8, fontweight="bold", color=CHARCOAL)
fig.text(0.055, 0.965,
         r"The uniquely represented tail lies in $[0,1/2]$, so translates at distinct integer prefix sums are disjoint.",
         ha="left", fontsize=9.4, color=MUTED)
fig.savefig(FIG / "cantorization.pdf", bbox_inches="tight")
fig.savefig(FIG / "cantorization.png", dpi=250, bbox_inches="tight")
plt.close(fig)

# ---------------------------------------------------------------------------
# Full-page cover art derived from all three exact coefficient spectra.
# ---------------------------------------------------------------------------
W, H = 2550, 3300
yy = np.linspace(0.0, 1.0, H, dtype=np.float32)[:, None]
xx = np.linspace(0.0, 1.0, W, dtype=np.float32)[None, :]
glow1 = np.exp(-(((xx - 0.72) / 0.42) ** 2 + ((yy - 0.34) / 0.34) ** 2))
glow2 = np.exp(-(((xx - 0.22) / 0.32) ** 2 + ((yy - 0.80) / 0.28) ** 2))
base = np.zeros((H, W, 3), dtype=np.float32)
base[:] = np.array([8, 12, 14], dtype=np.float32)
base += glow1[..., None] * np.array([0, 34, 31], dtype=np.float32)
base += glow2[..., None] * np.array([5, 20, 44], dtype=np.float32)
base += (1 - yy)[..., None] * np.array([2, 5, 6], dtype=np.float32)
img = Image.fromarray(np.clip(base, 0, 255).astype(np.uint8), mode="RGB")
del base, glow1, glow2, xx, yy

d = ImageDraw.Draw(img, "RGBA")
# Quiet network field in the upper two-thirds.
for k in range(15):
    y0 = 420 + k * 150
    pts = []
    for x in range(-100, W + 100, 40):
        y = y0 + 38 * math.sin(x / 260 + k * 0.48) + 14 * math.sin(x / 83 + k)
        pts.append((x, y))
    d.line(pts, fill=(42, 209, 137, 14), width=2)

# Perspective grid behind spectra.
vanish = (W * 0.66, H * 0.43)
for x in np.linspace(-200, W + 200, 22):
    d.line([(x, H * 0.96), vanish], fill=(198, 245, 221, 22), width=2)
for y in np.linspace(H * 0.52, H * 0.96, 16):
    d.line([(80, y), (W - 80, y)], fill=(198, 245, 221, 16), width=2)


def skyline(vals: list[int], origin: tuple[float, float], width: float, scale_y: float,
            accent: tuple[int, int, int, int], zero_marks: bool = False) -> list[tuple[float, float, int]]:
    ox, oy = origin
    sx = width / max(1, len(vals) - 1)
    bar_w = max(6, min(18, int(sx * 0.24)))
    peaks: list[tuple[float, float, int]] = []
    for i, value in enumerate(vals):
        x = ox + i * sx
        if value == 0:
            if zero_marks:
                d.line([(x - 7, oy + 14), (x + 7, oy + 14)], fill=(255, 185, 80, 100), width=3)
            peaks.append((x, oy, value))
            continue
        top = oy - value * scale_y
        depth = 22
        d.polygon([(x - bar_w, oy), (x + bar_w, oy),
                   (x + bar_w - depth, oy - depth * 0.28),
                   (x - bar_w - depth, oy - depth * 0.28)], fill=(0, 0, 0, 72))
        d.polygon([(x + bar_w, oy), (x + bar_w, top),
                   (x + bar_w - depth, top - depth * 0.28),
                   (x + bar_w - depth, oy - depth * 0.28)], fill=(25, 114, 220, 70))
        d.rectangle((x - bar_w, top, x + bar_w, oy), fill=accent,
                    outline=(198, 245, 221, 140), width=2)
        d.ellipse((x - bar_w - 5, top - 8, x + bar_w + 5, top + 10), fill=(198, 245, 221, 135))
        peaks.append((x, top, value))
    d.line([(x, y - 1) for x, y, _ in peaks], fill=(198, 245, 221, 185), width=4, joint="curve")
    return peaks

peaks_a = skyline(CA, (250, 2265), 1510, 82, (42, 209, 137, 205))
peaks_b = skyline(CB, (190, 2730), 2000, 72, (25, 114, 220, 198))
peaks_c = skyline(CC, (120, 3150), 2290, 58, (12, 141, 143, 205), zero_marks=True)

# A subtle highlighted void at multiplicity 2 behind the third spectrum.
y2 = 3150 - 2 * 58
d.line([(120, y2), (2410, y2)], fill=(179, 107, 0, 55), width=3)

# Glow on higher bars.
glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
gd = ImageDraw.Draw(glow, "RGBA")
for peaks, hue in [(peaks_a, (42, 209, 137, 55)), (peaks_b, (25, 114, 220, 55)), (peaks_c, (12, 141, 143, 55))]:
    for x, y, value in peaks:
        if value >= 3:
            gd.ellipse((x - 46, y - 46, x + 46, y + 46), fill=hue)
glow = glow.filter(ImageFilter.GaussianBlur(34))
img = Image.alpha_composite(img.convert("RGBA"), glow).convert("RGB")
img.save(FIG / "cover_art.png", quality=96)
img.save(ROOT / "Metriq_PRISM_Cardinal_Range_Certificates_Cover_MF-PRISM-MATH-2026-06_v2.2.png", quality=96)

print("Generated:")
for path in sorted(FIG.iterdir()):
    print(" -", path.relative_to(ROOT))
print(" - Metriq_PRISM_Cardinal_Range_Certificates_Cover_MF-PRISM-MATH-2026-06_v2.2.png")
