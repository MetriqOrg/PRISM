# Review guide

# Independent Mathematical Review Guide

## MF-PRISM-MATH-2026-06 - Finite Certificates for Three Unresolved Cardinal-Function Ranges

**Version reviewed:** 2.1  
**Issuer:** Metriq PRISM Laboratory, a research laboratory of Metriq Foundation, Inc.  
**Status:** Candidate result; not independently peer reviewed

## Central claim

The finite witnesses (1,2,2,3,3), (1,1,2,2,3,6), and (2,5,6,9,10,11,13) realize the positive coefficient ranges {1,2,3,4,5}, {1,2,3,5,6}, and {1,3,4,5}, respectively; each admits a Cantor achievement-set extension with the same range.

## Load-bearing review targets

1. Confirm the source classification table and the meaning of each finite, Cantor, and unrestricted column.
2. Multiply the three generating polynomials or independently enumerate all 32, 64, and 128 subsets.
3. Verify that the third coefficient profile has no coefficient equal to 2 while coefficients 1, 3, 4, and 5 all occur.
4. Audit the unique ternary tail, disjoint integer translates, multiplicity preservation, and Cantor topology.
5. Search for equivalent finite witnesses or later classification updates and assess all novelty claims.

## Review format requested

A useful review should identify the exact theorem, lemma, equation, figure, or
page involved; distinguish fatal, repairable, and expository issues; and supply
a counterexample, correction, independent derivation, or prior-art reference
where possible. Computational checks should be reported separately from review
of the infinite argument.

## Scope limitation

A successful reproduction of the included scripts does not establish the
candidate theorem, novelty, or priority. Independent mathematical reading is
required.


## Phase 2 review note

This guide applies to MF-PRISM-MATH-2026-06 Version 2.2. Reviewers should use the standalone reviewer packet and exact versioned PDF.
