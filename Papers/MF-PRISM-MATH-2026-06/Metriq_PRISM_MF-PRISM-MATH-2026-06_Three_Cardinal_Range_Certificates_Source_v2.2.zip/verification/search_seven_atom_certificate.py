#!/usr/bin/env python3
"""Bounded exact search used to discover the MF-MATH-2026-07 witness.

Search space: nondecreasing 7-tuples of positive integers with largest atom at
most 20. Solutions are normalized by gcd = 1. This is a bounded discovery
record, not a proof of global minimality.
"""
from __future__ import annotations

from math import gcd
from functools import reduce
from time import perf_counter

LENGTH = 7
MAX_ATOM = 20
TARGET = {1, 3, 4, 5}
MAX_MULTIPLICITY = max(TARGET)

nodes = 0
solutions: list[tuple[int, ...]] = []


def extend(coefficients: list[int], atom: int) -> list[int]:
    updated = coefficients + [0] * atom
    for exponent, coefficient in enumerate(coefficients):
        updated[exponent + atom] += coefficient
    return updated


def search(prefix: list[int], coefficients: list[int], next_minimum: int) -> None:
    global nodes
    nodes += 1

    if len(prefix) == LENGTH:
        positive_range = {c for c in coefficients if c > 0}
        if positive_range == TARGET and reduce(gcd, prefix) == 1:
            solutions.append(tuple(prefix))
        return

    for atom in range(next_minimum, MAX_ATOM + 1):
        updated = extend(coefficients, atom)

        # Coefficients only increase under later multiplication.
        if max(updated) > MAX_MULTIPLICITY:
            continue

        # Every future atom is at least 'atom'. Hence coefficients of z^t for
        # t < atom are frozen. Any frozen positive multiplicity outside the
        # target can never be repaired.
        if any(c > 0 and c not in TARGET for c in updated[:atom]):
            continue

        search(prefix + [atom], updated, atom)


def main() -> None:
    start = perf_counter()
    search([], [1], 1)
    elapsed = perf_counter() - start

    print("MF-MATH-2026-07 bounded discovery search")
    print(f"length: {LENGTH}")
    print(f"maximum atom: {MAX_ATOM}")
    print(f"target positive coefficient range: {sorted(TARGET)}")
    print(f"nodes visited: {nodes}")
    print(f"normalized solutions: {len(solutions)}")
    for solution in solutions:
        print(" ", solution)
    print(f"elapsed seconds: {elapsed:.6f}")
    print("BOUNDED SEARCH COMPLETED")


if __name__ == "__main__":
    main()
