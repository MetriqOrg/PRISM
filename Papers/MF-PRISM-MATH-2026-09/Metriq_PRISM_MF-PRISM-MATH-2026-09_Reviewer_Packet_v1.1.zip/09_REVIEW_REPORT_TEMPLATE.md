# Independent review report

**Reviewer:**  
**Affiliation:**  
**Date:**  
**Conflicts disclosed:**  

## Conclusion

- [ ] Correct as stated
- [ ] Correct subject to minor changes
- [ ] Major revision required
- [ ] Central claim not established

## Mathematical findings

List each issue with manuscript page, section, statement, and a reproducible explanation.

## Verification reproduction

State the environment, commands, and whether both supplied verifiers passed.

## Prior art and priority

List sources searched and any equivalent argument or earlier result found.

## Required corrections

Separate correctness issues from exposition, metadata, and priority issues.

## Publication recommendation

State whether the candidate should remain unchanged, be corrected, be withdrawn, or proceed to further review. This form does not itself constitute journal peer review.
