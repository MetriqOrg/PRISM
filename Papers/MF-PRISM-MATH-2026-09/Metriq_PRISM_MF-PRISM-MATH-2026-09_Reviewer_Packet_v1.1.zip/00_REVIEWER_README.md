# External reviewer packet - MF-PRISM-MATH-2026-09 Version 1.1

**Title:** A Bessel-Factorization Proof of Mathar's Recurrence for Type-ace Lattice Walks  
**Reserved DOI:** 10.5281/zenodo.21434724  
**Organizational creator and issuer:** Metriq PRISM Laboratory, Metriq Foundation, Inc.  
**Corresponding contributor:** Daniel H. Jeffery, Research Director, ORCID 0009-0001-1200-6042  
**Status:** Candidate proof; independent specialist and publication-priority review remain outstanding

The manuscript has nine PDF pages: one cover and eight numbered manuscript pages. Reviewers should assess the mathematics and prior-art position independently. Included exact computation and reproducible builds do not constitute independent mathematical validation or peer review.

Suggested order: read `01_MAIN_THEOREM.md`, follow `03_PROOF_DEPENDENCY_MAP.md`, complete `04_LEMMA_CHECKLIST.md`, compare the encoded scope in `06_VERIFICATION_SCOPE.md`, and report conclusions with `09_REVIEW_REPORT_TEMPLATE.md`.

Paper 09 Version 1.1 continues `MF-MATH-2026-09` Version 1.0. The predecessor remains preserved at repository commit `efcc595afd46c6f2c36a3206e4ba8e92814f8790`.
