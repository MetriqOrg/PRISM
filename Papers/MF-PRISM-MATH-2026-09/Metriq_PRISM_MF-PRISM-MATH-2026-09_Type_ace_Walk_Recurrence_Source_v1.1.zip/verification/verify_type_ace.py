#!/usr/bin/env python3
"""Exact verification for MF-PRISM-MATH-2026-09.

Checks:
- coefficients of the Bessel EGF from three independent coordinate sequences;
- Mathar's five-term recurrence;
- the lower-order companion recurrence;
- formal-series annihilation by L3 and L6;
- the noncommutative Ore identity (8x+3)^3 L6 = Q o L3.

All arithmetic is exact over the integers/rationals.
"""
from __future__ import annotations

from fractions import Fraction
from math import comb, factorial
from typing import Dict, List

N = 100


def egf_mul(a: List[int], b: List[int], nmax: int) -> List[int]:
    out = [0] * (nmax + 1)
    for n in range(nmax + 1):
        out[n] = sum(comb(n, k) * a[k] * b[n-k] for k in range(n + 1))
    return out


def catalan(k: int) -> int:
    return comb(2*k, k) // (k + 1)


# Coordinate A: nonnegative nearest-neighbor walk, endpoint 0.
coord_a = [catalan(n // 2) if n % 2 == 0 else 0 for n in range(N + 1)]
# Coordinate E: nonnegative nearest-neighbor walk, arbitrary endpoint.
coord_e = [comb(n, n // 2) for n in range(N + 1)]
# Unrestricted coordinate.
coord_u = [2**n for n in range(N + 1)]

walks = egf_mul(egf_mul(coord_a, coord_e, N), coord_u, N)
expected_initial = [1, 3, 11, 44, 188, 842, 3911, 18692, 91412, 455540, 2306028, 11829424]
assert walks[:len(expected_initial)] == expected_initial, (walks[:len(expected_initial)], expected_initial)


def mathar_residual(n: int) -> int:
    a = walks
    return (
        (n + 3) * (n + 2) * a[n]
        + 4 * (-3*n*n - 8*n - 3) * a[n-1]
        + 8 * (4*n*n + 3*n - 3) * a[n-2]
        + 48 * (n - 2)**2 * a[n-3]
        - 144 * (n - 2) * (n - 3) * a[n-4]
    )


def companion_residual(n: int) -> int:
    a = walks
    return (
        3 * (n + 2) * (n + 3) * a[n]
        + 2 * (4*n**3 - 5*n**2 - 37*n - 16) * a[n-1]
        - 4 * (n - 1) * (12*n**2 + 7*n - 14) * a[n-2]
        - 8 * (n - 1) * (n - 2) * (4*n - 25) * a[n-3]
        + 192 * (n - 1) * (n - 2) * (n - 3) * a[n-4]
    )

for n in range(4, N + 1):
    assert mathar_residual(n) == 0, ("Mathar", n, mathar_residual(n))
    assert companion_residual(n) == 0, ("companion", n, companion_residual(n))

# Polynomial utilities: dict exponent -> rational coefficient.
Poly = Dict[int, Fraction]
Operator = Dict[int, Poly]  # derivative order -> polynomial coefficient


def clean_poly(p: Poly) -> Poly:
    return {e: Fraction(c) for e, c in p.items() if c}


def p_add(a: Poly, b: Poly) -> Poly:
    out = dict(a)
    for e, c in b.items():
        out[e] = out.get(e, Fraction(0)) + c
    return clean_poly(out)


def p_mul(a: Poly, b: Poly) -> Poly:
    out: Poly = {}
    for ea, ca in a.items():
        for eb, cb in b.items():
            out[ea + eb] = out.get(ea + eb, Fraction(0)) + ca * cb
    return clean_poly(out)


def p_deriv(a: Poly, k: int = 1) -> Poly:
    out = dict(a)
    for _ in range(k):
        out = {e - 1: c * e for e, c in out.items() if e > 0}
    return clean_poly(out)


def op_clean(op: Operator) -> Operator:
    return {d: clean_poly(p) for d, p in op.items() if clean_poly(p)}


def op_compose(A: Operator, B: Operator) -> Operator:
    out: Operator = {}
    for i, ai in A.items():
        for j, bj in B.items():
            for k in range(i + 1):
                term_poly = p_mul(ai, p_deriv(bj, k))
                factor = Fraction(comb(i, k))
                term_poly = {e: factor*c for e, c in term_poly.items()}
                order = i - k + j
                out[order] = p_add(out.get(order, {}), term_poly)
    return op_clean(out)


def p_pow(a: Poly, n: int) -> Poly:
    out: Poly = {0: Fraction(1)}
    for _ in range(n):
        out = p_mul(out, a)
    return out


def egf_operator_coefficient(op: Operator, seq: List[int], m: int) -> Fraction:
    total = Fraction(0)
    for d, poly in op.items():
        for r, c in poly.items():
            if m >= r:
                index = m - r + d
                if 0 <= index < len(seq):
                    falling = factorial(m) // factorial(m - r)
                    total += c * falling * seq[index]
    return total

# Operators in normal form.
L3: Operator = {
    3: {3: Fraction(8), 2: Fraction(3)},
    2: {3: Fraction(-48), 2: Fraction(38), 1: Fraction(24)},
    1: {3: Fraction(-32), 2: Fraction(-268), 1: Fraction(-48), 0: Fraction(36)},
    0: {3: Fraction(192), 2: Fraction(104), 1: Fraction(-192), 0: Fraction(-108)},
}
L6: Operator = {
    6: {2: Fraction(1)},
    5: {2: Fraction(-12), 1: Fraction(14)},
    4: {2: Fraction(32), 1: Fraction(-140), 0: Fraction(42)},
    3: {2: Fraction(48), 1: Fraction(312), 0: Fraction(-332)},
    2: {2: Fraction(-144), 1: Fraction(240), 0: Fraction(584)},
    1: {1: Fraction(-576), 0: Fraction(192)},
    0: {0: Fraction(-288)},
}
Q: Operator = {
    3: {2: Fraction(64), 1: Fraction(48), 0: Fraction(9)},
    2: {2: Fraction(-384), 1: Fraction(-416), 0: Fraction(-102)},
    1: {1: Fraction(768), 0: Fraction(416)},
    0: {0: Fraction(-768)},
}

# Need extra coefficients because D^6 shifts the index.
series_max = 74
for m in range(series_max + 1):
    assert egf_operator_coefficient(L3, walks, m) == 0, ("L3", m, egf_operator_coefficient(L3, walks, m))
    assert egf_operator_coefficient(L6, walks, m) == 0, ("L6", m, egf_operator_coefficient(L6, walks, m))

left: Operator = {d: p_mul(p_pow({1: Fraction(8), 0: Fraction(3)}, 3), p) for d, p in L6.items()}
right = op_compose(Q, L3)
assert op_clean(left) == op_clean(right)

print("MF-PRISM-MATH-2026-09 exact verification")
print(f"Initial coefficients: {walks[:12]}")
print(f"Mathar recurrence: PASS for n=4..{N}")
print(f"Companion recurrence: PASS for n=4..{N}")
print(f"L3 formal-series annihilation: PASS through x^{series_max}")
print(f"L6 formal-series annihilation: PASS through x^{series_max}")
print("Ore identity (8x+3)^3 L6 = Q o L3: PASS exactly over Q[x]<D>")
