# MF-PRISM-MATH-2026-09 - A Bessel-Factorization Proof of Mathar's Recurrence for Type-ace Lattice Walks

**Canonical candidate version:** 1.1  
**Release date:** 18 July 2026  
**Organizational creator and issuer:** Metriq PRISM Laboratory, Metriq Foundation, Inc.  
**Corresponding contributor:** Daniel H. Jeffery, Research Director  
**ORCID:** https://orcid.org/0009-0001-1200-6042  
**Correspondence:** prism@metriq.org  
**Status:** Internally audited candidate proof; independent specialist and priority review outstanding  
**Internal decision:** PROCEED WITH MINOR METADATA CORRECTIONS  
**DOI:** 10.5281/zenodo.21434724

## Candidate result

This paper proves the recurrence listed as conjectural in OEIS A302186 for the number of three-dimensional lattice walks of type `ace`.

For the type-ace walk counts `a_n`, the manuscript derives

```text
F(x) = exp(2x) I_1(2x)/x * (I_0(2x) + I_1(2x))
```

and an exact differential-operator factorization

```text
(8x+3)^3 L6 = Q o L3,   L3 F = 0.
```

Coefficient extraction from `L6 F = 0` gives Mathar's five-term polynomial recurrence for every `n >= 4`.

## Package contents

- `metriq_type_ace_walk_recurrence_preprint.tex` — complete LuaLaTeX manuscript
- `release/Metriq_PRISM_MF-PRISM-MATH-2026-09_Type_ace_Walk_Recurrence_v1.1.pdf` - final DOI-bearing candidate manuscript
- `release/Metriq_PRISM_MF-PRISM-MATH-2026-09_Type_ace_Walk_Recurrence_Cover_v1.1.png` - 300-dpi cover generated from page 1
- `figures/` - formula-derived cover and manuscript figures
- `assets/` - approved PRISM publication lockups
- `verification/verify_type_ace.py` - dependency-free exact coefficient, recurrence, formal-series, and Ore-factorization checks
- `verification/verify_type_ace_sympy.py` - preserved predecessor-package verifier
- `verification/verification_output.txt` and `verification/verification_sympy_output.txt` - recorded successful outputs
- `REVIEW_GUIDE.md` - independent-review checklist
- `LITERATURE_STATUS.md` - dated status and priority-search limitations
- `QA/` - PDF metadata, font, preflight, disclaimer, build, and visual-review records

## Identifier history

`MF-PRISM-MATH-2026-09` Version 1.1 is the canonical successor to `MF-MATH-2026-09` Version 1.0. The historical release remains preserved in repository history at commit `efcc595afd46c6f2c36a3206e4ba8e92814f8790`; this identifier migration does not reset the original publication chronology.

## Creator and contributor

This candidate edition identifies Metriq PRISM Laboratory as organizational creator and issuer and Daniel H. Jeffery as Research Director and corresponding contributor.

## Build

A current LuaLaTeX distribution is required.

```bash
make paper
```

The rebuilt PDF is written to `build/`.

To regenerate figures:

```bash
python3 -m pip install -r requirements-figures.txt
make figures
```

## Verification

```bash
python3 verification/verify_type_ace.py
```

The primary script uses only exact integer and rational arithmetic. Its recorded output checks coefficients and both recurrences through `n = 100`, formal-series annihilation by `L3` and `L6` through degree 74, and the Ore identity exactly. The preserved SymPy verifier independently reproduces the predecessor package's checks through `n = 80`.

These calculations audit the displayed algebra. They do not constitute independent peer review, validation of novelty, or an exhaustive priority search.

## Institutional and computational-research disclaimer

This manuscript is an exploratory research preprint issued by the Metriq PRISM Laboratory, an interdisciplinary research laboratory of Metriq Foundation, Inc. PRISM—the Program for Research in Intelligent Systems and Methods—conducts research involving computational, mathematical, scientific, and machine-assisted methods. The work was developed as part of PRISM’s experimental research program in computationally assisted mathematics. Metriq Foundation, acting through the PRISM Laboratory, directed the research process, evaluated the resulting argument, determined the form and scope of the manuscript, and accepts responsibility for its publication as a candidate result. Generative artificial intelligence and other computational tools were used as research instruments to support construction search, symbolic and numerical analysis, literature review, proof development, verification, and manuscript preparation. Their use does not constitute independent validation of the results presented. This manuscript has not yet undergone independent peer review and should not be regarded as an established resolution of the stated problem unless and until its arguments have been examined and confirmed by qualified mathematicians. Independent verification, criticism, replication, and identification of errors are expressly invited.

## License

Research text, original mathematical figures, and documentation are licensed under **CC BY 4.0**. Verification code, build utilities, and figure-generation software are licensed under the **MIT License**. Metriq and PRISM names, marks, logos, publication lockups, and trade dress are excluded from those grants.

## Preferred candidate-edition citation

Metriq PRISM Laboratory. *A Bessel-Factorization Proof of Mathar's Recurrence for Type-ace Lattice Walks*. MF-PRISM-MATH-2026-09, Version 1.1, 18 July 2026. Corresponding contributor: Daniel H. Jeffery. DOI: 10.5281/zenodo.21434724.
