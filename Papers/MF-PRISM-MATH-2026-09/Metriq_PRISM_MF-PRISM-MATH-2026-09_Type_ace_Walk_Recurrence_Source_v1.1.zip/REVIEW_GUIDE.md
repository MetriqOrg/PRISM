# Independent Review Guide - MF-PRISM-MATH-2026-09

## Principal claim

Verify that the type-ace walk sequence A302186 satisfies Mathar's conjectured recurrence for every `n >= 4`.

## Proof-critical checkpoints

1. **Coordinate enumeration**
   - Type a: Catalan counts in even length and zero in odd length.
   - Type c: `binom(s, floor(s/2))`.
   - Type e: `2^t`.

2. **EGF factorization**
   - Confirm labelled interleaving gives
     `F(x) = exp(2x) I1(2x)/x (I0(2x)+I1(2x))`.

3. **Bessel elimination**
   - Check `u' = 2v`, `v' = 2u-v/x`.
   - Form the symmetric-square system for `(u^2, uv, v^2)`.
   - Eliminate the state variables and verify the displayed third-order ODE for `z = exp(-2x)F`.
   - Check the gauge transformation to `L3 F = 0`.

4. **Ore factorization**
   - Expand differential operators with `D x = x D + 1`.
   - Verify `(8x+3)^3 L6 = Q o L3` coefficient by coefficient.

5. **Coefficient extraction**
   - Apply `[x^m/m!] x^p D^q F = (m)_p a_{m-p+q}`.
   - Confirm that the coefficient of `x^(n-4)/(n-4)!` in `L6 F` is precisely the stated recurrence.

## Priority and literature questions

- Determine whether a proof appeared after the OEIS recurrence comment dated 29 October 2025.
- Search for equivalent Bessel, creative-telescoping, or holonomic derivations not indexed under “type ace” or A302186.
- Confirm the interpretation of Dershowitz's coordinate-type conventions.

## Reproducibility

Run:

```bash
python3 verification/verify_type_ace.py
```

The script is an audit, not a replacement for the checks above.
