# Changelog

## Version 1.1 - 18 July 2026

- Migrated the current identifier from `MF-MATH-2026-09` to `MF-PRISM-MATH-2026-09` while preserving the Version 1.0 predecessor record.
- Added reserved version DOI `10.5281/zenodo.21434724` to the manuscript and release metadata.
- Added the organizational creator and Daniel H. Jeffery's Research Director and corresponding-contributor role.
- Added explicit creator/contributor, funding, competing-interests, licensing, data/code, AI-use, DOI, and version-history declarations.
- Added the supplied dependency-free exact verifier while preserving and rerunning the original SymPy verifier.
- Rebuilt the figures, manuscript, cover, source package, reviewer packet, and checksums.

These publication-control changes do not constitute independent mathematical validation.

## Version 1.0 - 16 July 2026

- Initial release of MF-MATH-2026-09.
- Derived the exact Bessel exponential generating function for type-ace walks.
- Derived a third-order annihilating differential operator.
- Proved the exact Ore factorization implying Mathar's conjectured recurrence.
- Added a lower-order companion recurrence.
- Added exact verification through `n = 80`, reproducible figures, PRISM branding, review guide, licensing, and QA records.
