#!/usr/bin/env python3
"""Generate formula-derived artwork and figures for MF-PRISM-MATH-2026-03.

The illustrations use finite binary truncations whose digit positions are split
between two disjoint block families. Their finite Minkowski sum is exactly the
full dyadic grid at the displayed truncation level.
"""
from __future__ import annotations

from pathlib import Path
import math
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.patches import FancyBboxPatch, PathPatch
from matplotlib.path import Path as MplPath

ROOT = Path(__file__).resolve().parent
FIG = ROOT / "figures"
FIG.mkdir(parents=True, exist_ok=True)

# Metriq v3.1 palette.
MINT = "#C6F5DD"
SIGNAL = "#2AD189"
EMERALD = "#06A269"
TEAL = "#045B5D"
TEAL_LIGHT = "#0C8D8F"
BLUE = "#1972DC"
CHARCOAL = "#333333"
NEAR_BLACK = "#0B0D0E"
OFF_WHITE = "#F7FAF9"
MUTED = "#5F6B6B"
BORDER = "#D6E2DE"

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "mathtext.fontset": "dejavusans",
    "axes.unicode_minus": False,
})


def digit_positions(block_lengths: list[int]) -> tuple[list[int], list[int]]:
    """Return 1-indexed binary digit positions assigned to A and B."""
    a: list[int] = []
    b: list[int] = []
    start = 1
    for j, length in enumerate(block_lengths, start=1):
        block = list(range(start, start + length))
        (a if j % 2 else b).extend(block)
        start += length
    return a, b


def prefix_numerators(positions: list[int], n_digits: int) -> np.ndarray:
    """All integer numerators at denominator 2**n_digits from selected positions."""
    weights = [1 << (n_digits - p) for p in positions]
    vals = np.array([0], dtype=np.int64)
    for w in weights:
        vals = np.concatenate((vals, vals + w))
    return np.sort(vals)


def add_glow(ax, x: np.ndarray, y: np.ndarray, color: str, widths=(10, 5, 1.5), alphas=(0.025, 0.055, 0.35)):
    for lw, alpha in zip(widths, alphas):
        ax.plot(x, y, color=color, lw=lw, alpha=alpha, solid_capstyle="round")


def bezier(ax, p0, p1, p2, p3, color, lw=0.8, alpha=0.16):
    path = MplPath([p0, p1, p2, p3], [MplPath.MOVETO, MplPath.CURVE4, MplPath.CURVE4, MplPath.CURVE4])
    ax.add_patch(PathPatch(path, facecolor="none", edgecolor=color, lw=lw, alpha=alpha))


def cover_art() -> None:
    width, height, dpi = 8.5, 11.0, 220
    fig = plt.figure(figsize=(width, height), dpi=dpi)
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

    # Layered dark background with a teal-blue field toward the lower right.
    nx, ny = 1200, 1550
    xx, yy = np.meshgrid(np.linspace(0, 1, nx), np.linspace(0, 1, ny))
    radial = np.exp(-((xx - 0.78) ** 2 / 0.12 + (yy - 0.30) ** 2 / 0.10))
    radial2 = np.exp(-((xx - 0.20) ** 2 / 0.20 + (yy - 0.06) ** 2 / 0.06))
    vertical = np.clip(1.0 - yy, 0, 1)
    base = np.zeros((ny, nx, 3), dtype=float)
    c0 = np.array([11, 13, 14]) / 255.0
    c1 = np.array([4, 91, 93]) / 255.0
    c2 = np.array([25, 114, 220]) / 255.0
    base[:] = c0
    base += radial[..., None] * 0.52 * (c1 - c0)
    base += radial2[..., None] * 0.22 * (c2 - c0)
    base += vertical[..., None] * np.array([0.002, 0.010, 0.014])
    base = np.clip(base, 0, 1)
    ax.imshow(base, extent=[0, 1, 0, 1], origin="lower", aspect="auto")

    # Subtle grid representing scale checkpoints.
    for y in np.linspace(0.08, 0.48, 9):
        ax.plot([0.06, 0.95], [y, y], color="white", lw=0.35, alpha=0.035)
    for x in np.linspace(0.06, 0.95, 18):
        ax.plot([x, x], [0.07, 0.49], color="white", lw=0.35, alpha=0.025)

    # Exact finite digit split and finite achievement sets.
    blocks = [1, 2, 3, 5, 7]  # 18 positions, alternating ownership.
    n = sum(blocks)
    apos, bpos = digit_positions(blocks)
    anum = prefix_numerators(apos, n)
    bnum = prefix_numerators(bpos, n)
    den = float(1 << n)
    avals = anum / den
    bvals = bnum / den

    # Digit-block rail: widths are schematic but labels preserve actual block sizes.
    x0, x1 = 0.075, 0.925
    yrail = 0.445
    visual_weights = np.sqrt(np.asarray(blocks, dtype=float))
    visual_weights /= visual_weights.sum()
    cursor = x0
    centers = []
    for j, (length, frac) in enumerate(zip(blocks, visual_weights), start=1):
        w = (x1 - x0) * frac
        color = SIGNAL if j % 2 else BLUE
        patch = FancyBboxPatch((cursor, yrail - 0.012), w - 0.002, 0.024,
                               boxstyle="round,pad=0.001,rounding_size=0.004",
                               linewidth=0.45, edgecolor="white", facecolor=color, alpha=0.72)
        ax.add_patch(patch)
        centers.append(cursor + w / 2)
        # Fine ticks for the actual count, capped visually.
        for t in range(length):
            tx = cursor + (t + 0.5) * w / length
            ax.plot([tx, tx], [yrail - 0.008, yrail + 0.008], color="white", lw=0.35, alpha=0.28)
        cursor += w

    # Flow from digit blocks into the two sparse sets.
    for j, cx in enumerate(centers, start=1):
        target_y = 0.355 if j % 2 else 0.275
        target_x = 0.11 + 0.78 * (cx - x0) / (x1 - x0)
        bezier(ax, (cx, yrail - 0.014), (cx, 0.415), (target_x, target_y + 0.035), (target_x, target_y),
               SIGNAL if j % 2 else BLUE, lw=0.9, alpha=0.16)

    # Sparse finite sets as luminous rugs.
    def rug(vals, y, color, max_lines=2200):
        if len(vals) > max_lines:
            idx = np.linspace(0, len(vals) - 1, max_lines, dtype=int)
            vals = vals[idx]
        xs = 0.08 + 0.84 * vals
        segs = np.stack([np.column_stack((xs, np.full_like(xs, y - 0.012))),
                         np.column_stack((xs, np.full_like(xs, y + 0.012)))], axis=1)
        ax.add_collection(LineCollection(segs, colors=color, linewidths=0.55, alpha=0.30))
        ax.plot([0.08, 0.92], [y, y], color="white", lw=0.5, alpha=0.10)

    rug(avals, 0.350, SIGNAL)
    rug(bvals, 0.270, BLUE)

    # Exact dyadic sum grid: every numerator 0,...,2^n-1 occurs.
    full = np.linspace(0, 1 - 1 / den, 1 << n)
    # Rasterize as density band rather than drawing 262k individual lines.
    band = np.ones((18, 1600, 4), dtype=float)
    rgb = np.array([198, 245, 221]) / 255.0
    band[..., :3] = rgb
    # A softly modulated alpha to imply individual dyadic points.
    phase = np.linspace(0, 72 * np.pi, 1600)
    alpha = 0.20 + 0.18 * (0.5 + 0.5 * np.sin(phase))
    band[..., 3] = alpha[None, :]
    ax.imshow(band, extent=[0.08, 0.92, 0.155, 0.195], origin="lower", aspect="auto")
    add_glow(ax, np.array([0.08, 0.92]), np.array([0.175, 0.175]), MINT,
             widths=(18, 8, 2.2), alphas=(0.025, 0.055, 0.60))

    # Sample exact addition curves. Use disjoint bits, so no carries occur.
    sample_pairs = [(0, 0), (len(avals)//7, len(bvals)//3), (len(avals)//3, len(bvals)//2),
                    (2*len(avals)//3, 3*len(bvals)//4), (len(avals)-1, len(bvals)-1)]
    for ia, ib in sample_pairs:
        xa = 0.08 + 0.84 * avals[ia]
        xb = 0.08 + 0.84 * bvals[ib]
        xs = 0.08 + 0.84 * ((anum[ia] + bnum[ib]) / den)
        bezier(ax, (xa, 0.338), (xa, 0.235), (xs, 0.225), (xs, 0.195), SIGNAL, lw=0.7, alpha=0.25)
        bezier(ax, (xb, 0.258), (xb, 0.220), (xs, 0.210), (xs, 0.195), BLUE, lw=0.7, alpha=0.25)

    # Low-opacity annotations embedded in the art; main text is overlaid in TeX.
    ax.text(0.075, 0.475, "ALTERNATING DIGIT BLOCKS", color="white", alpha=0.38,
            fontsize=7.0, fontweight="bold", ha="left", va="bottom")
    ax.text(0.075, 0.371, "ZERO-DIMENSIONAL SUMMAND A", color=SIGNAL, alpha=0.70,
            fontsize=6.6, fontweight="bold", ha="left", va="bottom")
    ax.text(0.075, 0.291, "ZERO-DIMENSIONAL SUMMAND B", color=BLUE, alpha=0.72,
            fontsize=6.6, fontweight="bold", ha="left", va="bottom")
    ax.text(0.075, 0.205, "FULL DYADIC SUM GRID", color=MINT, alpha=0.66,
            fontsize=6.6, fontweight="bold", ha="left", va="bottom")
    ax.text(0.92, 0.205, "[0,1]", color="white", alpha=0.55,
            fontsize=7.0, ha="right", va="bottom")

    # Fine lower-edge signal trace.
    x = np.linspace(0.06, 0.95, 1800)
    y = 0.074 + 0.006 * np.sin(50 * x) * np.exp(-2.0 * (x - 0.5) ** 2)
    add_glow(ax, x, y, SIGNAL, widths=(7, 3, 0.8), alphas=(0.015, 0.04, 0.28))

    fig.savefig(FIG / "cover_art.png", dpi=dpi, facecolor=NEAR_BLACK, bbox_inches=None, pad_inches=0)
    plt.close(fig)


def alternating_blocks_figure() -> None:
    fig, ax = plt.subplots(figsize=(7.25, 3.45), dpi=220)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    fig.patch.set_facecolor("white")

    lengths = np.array([1, 3, 8, 24, 70, 210], dtype=float)
    widths = np.log1p(lengths)
    widths /= widths.sum()
    x0, x1 = 0.055, 0.955
    cursor = x0
    boundaries = [cursor]
    for j, frac in enumerate(widths, start=1):
        w = (x1 - x0) * frac
        color = SIGNAL if j % 2 else BLUE
        patch = FancyBboxPatch((cursor, 0.56), w - 0.003, 0.14,
                               boxstyle="round,pad=0.004,rounding_size=0.012",
                               linewidth=0.8, edgecolor=CHARCOAL, facecolor=color, alpha=0.86)
        ax.add_patch(patch)
        ax.text(cursor + w/2, 0.635, rf"$I_{j}$", ha="center", va="center",
                color="white", fontsize=10, fontweight="bold")
        ax.text(cursor + w/2, 0.535, "A" if j % 2 else "B", ha="center", va="top",
                color=color, fontsize=8.5, fontweight="bold")
        cursor += w
        boundaries.append(cursor)

    ax.text(x0, 0.79, r"original sequence $a_1,a_2,\ldots$ split into finite consecutive blocks",
            ha="left", va="bottom", color=CHARCOAL, fontsize=10.5)
    ax.plot([x0, x1], [0.73, 0.73], color=BORDER, lw=1)

    # Tail checkpoints: after the intervening block, the waiting color's future tail is tiny.
    checkpoint_specs = [
        (boundaries[2], 0.42, SIGNAL, r"$R^A_{p_1}\leq T_{N_2}\leq 2^{-p_1^2}$"),
        (boundaries[3], 0.26, BLUE, r"$R^B_{q_1}\leq T_{N_3}\leq 2^{-q_1^2}$"),
        (boundaries[4], 0.12, SIGNAL, r"$R^A_{p_2}\leq T_{N_4}\leq 2^{-p_2^2}$"),
    ]
    for x, y, color, label in checkpoint_specs:
        ax.annotate("", xy=(x, 0.555), xytext=(x, y + 0.06),
                    arrowprops=dict(arrowstyle="-|>", lw=1.2, color=color, alpha=0.9))
        ax.text(x, y, label, ha="center", va="center", color=color, fontsize=10,
                bbox=dict(boxstyle="round,pad=0.28", fc=OFF_WHITE, ec=BORDER, lw=0.7))

    ax.text(0.955, 0.02,
            r"At each checkpoint: at most $2^m$ cylinders, each of diameter $R_m\leq 2^{-m^2}$.",
            ha="right", va="bottom", color=MUTED, fontsize=8.8)

    fig.savefig(FIG / "alternating_blocks.pdf", bbox_inches="tight")
    fig.savefig(FIG / "alternating_blocks.png", dpi=220, bbox_inches="tight")
    plt.close(fig)


def binary_sumset_figure() -> None:
    blocks = [1, 2, 3, 4, 6]
    n = sum(blocks)
    apos, bpos = digit_positions(blocks)
    anum = prefix_numerators(apos, n)
    bnum = prefix_numerators(bpos, n)
    den = float(1 << n)
    avals = anum / den
    bvals = bnum / den

    fig, ax = plt.subplots(figsize=(7.25, 4.2), dpi=220)
    ax.set_xlim(-0.01, 1.01)
    ax.set_ylim(0, 1)
    ax.axis("off")

    def rug(vals, y, color, height=0.095, max_lines=3000):
        if len(vals) > max_lines:
            vals = vals[np.linspace(0, len(vals) - 1, max_lines, dtype=int)]
        segs = [((float(x), y - height/2), (float(x), y + height/2)) for x in vals]
        ax.add_collection(LineCollection(segs, colors=color, linewidths=0.55, alpha=0.55))
        ax.plot([0, 1], [y, y], color=CHARCOAL, lw=0.5, alpha=0.20)

    rug(avals, 0.76, SIGNAL)
    rug(bvals, 0.48, BLUE)
    full = np.arange(1 << n) / den
    rug(full, 0.18, TEAL, height=0.13, max_lines=4096)

    ax.text(0, 0.89, r"finite prefix of $C_A$ (digits from odd blocks)", color=EMERALD,
            fontsize=10.5, fontweight="bold", ha="left")
    ax.text(0, 0.61, r"finite prefix of $C_B$ (digits from even blocks)", color=BLUE,
            fontsize=10.5, fontweight="bold", ha="left")
    ax.text(0, 0.31, r"$C_A+C_B$: every $2^{-16}$ dyadic cell is attained", color=TEAL,
            fontsize=10.5, fontweight="bold", ha="left")

    # A few exact no-carry examples.
    examples = [(0.14, 0.31), (0.42, 0.13), (0.67, 0.21)]
    for xa_target, xb_target in examples:
        ia = int(np.argmin(np.abs(avals - xa_target)))
        ib = int(np.argmin(np.abs(bvals - xb_target)))
        xa, xb = avals[ia], bvals[ib]
        xs = (anum[ia] + bnum[ib]) / den
        ax.annotate("", xy=(xs, 0.245), xytext=(xa, 0.705),
                    arrowprops=dict(arrowstyle="-", connectionstyle="arc3,rad=-0.16", color=SIGNAL, lw=0.8, alpha=0.32))
        ax.annotate("", xy=(xs, 0.245), xytext=(xb, 0.425),
                    arrowprops=dict(arrowstyle="-", connectionstyle="arc3,rad=0.12", color=BLUE, lw=0.8, alpha=0.32))
        ax.plot(xs, 0.18, marker="o", ms=2.8, color=CHARCOAL, alpha=0.65)

    ax.text(0.5, 0.02,
            r"Disjoint binary digit positions imply exact addition without carries.",
            ha="center", va="bottom", color=MUTED, fontsize=9.2)

    fig.savefig(FIG / "binary_sumset.pdf", bbox_inches="tight")
    fig.savefig(FIG / "binary_sumset.png", dpi=220, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    cover_art()
    alternating_blocks_figure()
    binary_sumset_figure()
    print("Generated:")
    for path in sorted(FIG.iterdir()):
        print(f"  {path.name}")
