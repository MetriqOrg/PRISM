# Source Problem and Citation

**Source:** Achievement Sets - Current Results and Open Problems  
**URL:** https://arxiv.org/abs/2512.17285

## Problem context

Problem 16 asks whether every infinite achievable set is a sum of two achievable sets of Hausdorff dimension zero.

## Reviewer task

Confirm the exact source wording, intended scope, and whether the candidate theorem actually answers that problem or conjecture. Search for equivalent prior formulations and results.
