# Lemma and Claim Checklist

Use **Confirmed**, **Objection**, **Not checked**, or **Not applicable**.

| # | Claim / step | Reviewer status | Notes |
|---:|---|---|---|
| 1 | **Prefix-tail cover:** Cover an achievement set by at most 2^m cylinders of diameter equal to a subsequence tail. |  |  |
| 2 | **Zero-dimensional checkpoint criterion:** Show that super-exponentially small tails at infinitely many checkpoints force dimension zero. |  |  |
| 3 | **Alternating-block partition:** Choose alternating finite blocks so each complementary subsequence receives its own super-exponential checkpoints. |  |  |
| 4 | **Checkpoint-tail lemma:** Bound the tail of each factor at the chosen checkpoints. |  |  |
| 5 | **Minkowski recombination:** Split every binary choice sequence across A and B to prove E(a)=E(a|A)+E(a|B). |  |  |
| 6 | **Cantor and multi-factor consequences:** Establish compact perfect totally disconnected factors and extend the construction. |  |  |

## Final implications

| Question | Response |
|---|---|
| Does every imported theorem apply under its exact hypotheses? |  |
| Does the main conclusion follow from the proved intermediate claims? |  |
| Is the source problem interpreted correctly? |  |
| Is the result novel to the best of the reviewer's knowledge? |  |
