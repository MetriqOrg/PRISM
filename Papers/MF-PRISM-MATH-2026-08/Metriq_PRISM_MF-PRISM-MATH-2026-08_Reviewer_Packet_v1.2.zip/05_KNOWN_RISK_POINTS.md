# Known Risk Points

## Internal risk level

**Moderate**

## Questions requiring adversarial review

1. Is the endpoint resolvent identity or CHS coefficient interpretation already explicit in the literature?
2. Are the reflection support bounds exact for every n and m, including n=1 and m=0 boundary cases?
3. Does the source formula indeed omit one nonzero image at m=n+1?
4. Are the recurrence and examples stated with consistent indexing conventions?

## Required corrections already identified

- Ask the source authors to confirm the intended formulas and the equality-case correction before publicizing the correction strongly.
- Expand the prior-art search to continuants, Jacobi matrices, Green functions, lattice-path kernels, and complete homogeneous symmetric functions.
- Clarify that the direct-lattice-path meaning is the principal contribution even if the resolvent identity is known.
- Update identifier, metadata, correspondence, DOI placeholder, and citation.
