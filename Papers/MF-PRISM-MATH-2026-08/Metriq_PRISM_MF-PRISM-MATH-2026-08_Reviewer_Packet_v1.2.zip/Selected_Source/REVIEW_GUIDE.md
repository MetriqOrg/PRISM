# Review guide

# Independent Mathematical Review Guide

## MF-PRISM-MATH-2026-08 - Endpoint Walks Evaluate the Complete Homogeneous Symmetric Norms of Path Graphs

**Version reviewed:** 1.1  
**Issuer:** Metriq PRISM Laboratory, a research laboratory of Metriq Foundation, Inc.  
**Status:** Candidate result; not independently peer reviewed

## Central claim

For the path graph P_n and m>=0, the manuscript proves h_(2m)(lambda(P_n))=(A(P_n)^(n-1+2m))_(1n), derives the exact spectral and binomial formulas, and corrects a finite-support boundary condition in the motivating conjecture.

## Load-bearing review targets

1. Verify the endpoint cofactor identity for (I-tA_n)^(-1)_(1n), including inverse indexing and signs.
2. Check the coefficient shift connecting the resolvent series to complete homogeneous symmetric polynomials.
3. Audit the two-barrier reflection kernel, finite support endpoints, and the equality-case correction when m=n+1.
4. Verify the rational generating function and recurrence in the even-degree parameter.
5. Search continuant, Jacobi-matrix, lattice-path, and symmetric-function literature for implicit or explicit prior forms of the endpoint-resolvent identity.

## Review format requested

A useful review should identify the exact theorem, lemma, equation, figure, or
page involved; distinguish fatal, repairable, and expository issues; and supply
a counterexample, correction, independent derivation, or prior-art reference
where possible. Computational checks should be reported separately from review
of the infinite argument.

## Scope limitation

A successful reproduction of the included scripts does not establish the
candidate theorem, novelty, or priority. Independent mathematical reading is
required.


## Phase 2 review note

This guide applies to MF-PRISM-MATH-2026-08 Version 1.2. Reviewers should use the standalone reviewer packet and exact versioned PDF.
