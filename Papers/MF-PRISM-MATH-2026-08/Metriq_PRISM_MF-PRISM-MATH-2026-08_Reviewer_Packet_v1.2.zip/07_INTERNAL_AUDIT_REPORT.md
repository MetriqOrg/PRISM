# Internal AI-Assisted Audit Report

**Decision:** PROCEED WITH MINOR CORRECTIONS  
**Risk:** Moderate

## Findings

- The endpoint cofactor calculation is correct: the minor is triangular with product (-t)^(n-1), and the cofactor sign produces t^(n-1).
- Coefficient comparison yields the stated shift n-1+r and gives a direct walk interpretation.
- The spectral formula follows from the standard sine eigenbasis of a path.
- The two-barrier image formula and its reindexing were checked against dynamic programming.
- The exact support bounds include j=-m/(n+1) when n+1 divides m; omitting that term lowers the equality case by exactly one.
- The included exact verifier compared endpoint walks, determinant coefficients, reflection sums, and corrected formulas for 1,176 parameter pairs.

## Corrections / actions

- Ask the source authors to confirm the intended formulas and the equality-case correction before publicizing the correction strongly.
- Expand the prior-art search to continuants, Jacobi matrices, Green functions, lattice-path kernels, and complete homogeneous symmetric functions.
- Clarify that the direct-lattice-path meaning is the principal contribution even if the resolvent identity is known.
- Update identifier, metadata, correspondence, DOI placeholder, and citation.

## Interpretive rule

This report records only an internal hostile audit. It is not evidence that an independent mathematician has verified the proof.
