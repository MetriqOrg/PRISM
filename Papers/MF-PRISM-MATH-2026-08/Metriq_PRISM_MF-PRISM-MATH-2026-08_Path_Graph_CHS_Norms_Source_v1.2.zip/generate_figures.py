#!/usr/bin/env python3
"""Generate formula-derived artwork for MF-PRISM-MATH-2026-08."""

from __future__ import annotations

import math
import random
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Circle, FancyBboxPatch

ROOT = Path(__file__).resolve().parent
FIG = ROOT / "figures"
FIG.mkdir(exist_ok=True)

# Metriq palette v3.1
MINT = "#C6F5DD"
SIGNAL = "#2AD189"
EMERALD = "#06A269"
TEAL = "#045B5D"
TEAL_LIGHT = "#0C8D8F"
BLUE = "#1972DC"
CHARCOAL = "#333333"
NEAR_BLACK = "#0B0D0E"
OFF_WHITE = "#F7FAF9"
MUTED = "#5F6B6B"
BORDER = "#D6E2DE"
WARNING = "#B36B00"


def completion_counts(n: int, length: int, end: int) -> list[list[int]]:
    """counts[t][y] = number of completions from (t,y) to (length,end)."""
    counts = [[0] * n for _ in range(length + 1)]
    counts[length][end] = 1
    for t in range(length - 1, -1, -1):
        for y in range(n):
            total = 0
            if y > 0:
                total += counts[t + 1][y - 1]
            if y + 1 < n:
                total += counts[t + 1][y + 1]
            counts[t][y] = total
    return counts


def sample_walk(n: int, m: int, rng: random.Random) -> list[int]:
    length = n - 1 + 2 * m
    counts = completion_counts(n, length, n - 1)
    y = 0
    ys = [y]
    for t in range(length):
        options: list[tuple[int, int]] = []
        if y > 0:
            options.append((y - 1, counts[t + 1][y - 1]))
        if y + 1 < n:
            options.append((y + 1, counts[t + 1][y + 1]))
        total = sum(w for _, w in options)
        if total <= 0:
            raise RuntimeError("no admissible continuation")
        r = rng.randrange(total)
        acc = 0
        for ny, weight in options:
            acc += weight
            if r < acc:
                y = ny
                break
        ys.append(y)
    return ys


def add_glow_line(ax, x, y, color, lw=1.4, alpha=0.85, glow=4):
    for k in range(glow, 0, -1):
        ax.plot(x, y, color=color, lw=lw + 2.2 * k, alpha=alpha * 0.025, solid_capstyle="round")
    ax.plot(x, y, color=color, lw=lw, alpha=alpha, solid_capstyle="round")


def make_cover() -> None:
    rng = random.Random(260608)
    width_px, height_px = 2550, 3300
    dpi = 300
    fig = plt.figure(figsize=(width_px / dpi, height_px / dpi), dpi=dpi)
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

    # Layered dark background with radial teal illumination.
    ny, nx = 1000, 800
    yy, xx = np.mgrid[0:1:complex(ny), 0:1:complex(nx)]
    base = np.zeros((ny, nx, 3), dtype=float)
    base[:] = np.array([11, 13, 14]) / 255.0
    glow1 = np.exp(-(((xx - 0.68) / 0.48) ** 2 + ((yy - 0.45) / 0.36) ** 2) * 2.2)
    glow2 = np.exp(-(((xx - 0.18) / 0.35) ** 2 + ((yy - 0.82) / 0.28) ** 2) * 2.6)
    teal = np.array([4, 91, 93]) / 255.0
    blue = np.array([25, 114, 220]) / 255.0
    base += glow1[..., None] * teal * 0.30
    base += glow2[..., None] * blue * 0.12
    vignette = 1 - 0.38 * ((xx - 0.5) ** 2 + (yy - 0.5) ** 2)
    base *= np.clip(vignette[..., None], 0.72, 1.0)
    ax.imshow(np.clip(base, 0, 1), extent=[0, 1, 0, 1], origin="lower", aspect="auto")

    # Spectral sine modes in the upper-middle background.
    xs = np.linspace(0.08, 0.94, 900)
    for k, (amp, phase, col, alpha) in enumerate([
        (0.030, 0.0, BLUE, 0.20),
        (0.020, 0.7, SIGNAL, 0.17),
        (0.014, 1.4, MINT, 0.11),
    ]):
        ys = 0.62 + amp * np.sin((k + 1) * math.pi * (xs - 0.08) / 0.86 + phase)
        add_glow_line(ax, xs, ys, col, lw=0.7, alpha=alpha, glow=2)

    # Reflection strip and exact endpoint-to-endpoint trajectories.
    n, m = 9, 8
    L = n - 1 + 2 * m
    x0, x1 = 0.075, 0.935
    y0, y1 = 0.255, 0.555
    X = np.linspace(x0, x1, L + 1)

    # Faint lattice and strip boundaries.
    for t in range(L + 1):
        x = x0 + (x1 - x0) * t / L
        ax.plot([x, x], [y0 - 0.06, y1 + 0.06], color=OFF_WHITE, lw=0.22, alpha=0.035)
    for v in range(n):
        y = y0 + (y1 - y0) * v / (n - 1)
        ax.plot([x0, x1], [y, y], color=OFF_WHITE, lw=0.25, alpha=0.055)
    ax.plot([x0, x1], [y0 - 0.018, y0 - 0.018], color=WARNING, lw=0.85, alpha=0.48)
    ax.plot([x0, x1], [y1 + 0.018, y1 + 0.018], color=WARNING, lw=0.85, alpha=0.48)

    walks = [sample_walk(n, m, rng) for _ in range(13)]
    for idx, ys_raw in enumerate(walks):
        Y = y0 + (y1 - y0) * np.array(ys_raw) / (n - 1)
        col = [SIGNAL, MINT, TEAL_LIGHT, BLUE][idx % 4]
        add_glow_line(ax, X, Y, col, lw=0.8 + 0.16 * (idx % 3), alpha=0.23 + 0.035 * (idx % 4), glow=2)
        # Image paths outside the strip: direct visual reference to the reflection proof.
        if idx < 5:
            ax.plot(X, 2 * (y0 - 0.018) - Y, color=col, lw=0.55, alpha=0.055)
            ax.plot(X, 2 * (y1 + 0.018) - Y, color=col, lw=0.55, alpha=0.055)

    # Path graph P_9 below the trajectory field.
    node_y = 0.185
    node_xs = np.linspace(0.12, 0.88, n)
    ax.plot(node_xs, [node_y] * n, color=MINT, lw=1.5, alpha=0.70)
    for i, x in enumerate(node_xs):
        for rad, a in [(0.020, 0.025), (0.014, 0.055), (0.010, 0.11)]:
            ax.add_patch(Circle((x, node_y), rad, facecolor=SIGNAL, edgecolor="none", alpha=a))
        face = MINT if i in (0, n - 1) else SIGNAL
        ax.add_patch(Circle((x, node_y), 0.0065, facecolor=face, edgecolor=OFF_WHITE, lw=0.35, alpha=0.98))

    # Endpoint rays upward to the walk strip.
    ax.plot([node_xs[0], x0], [node_y, y0], color=SIGNAL, lw=0.75, alpha=0.28)
    ax.plot([node_xs[-1], x1], [node_y, y1], color=SIGNAL, lw=0.75, alpha=0.28)

    # Large translucent Chebyshev / determinant motif behind lower field.
    theta = np.linspace(0, math.pi, 500)
    rx = 0.50 + 0.34 * np.cos(theta)
    ry = 0.11 + 0.035 * np.sin(9 * theta)
    ax.plot(rx, ry, color=BLUE, lw=0.8, alpha=0.12)

    # Small accent blocks.
    ax.add_patch(FancyBboxPatch((0.078, 0.665), 0.19, 0.008,
                                boxstyle="round,pad=0,rounding_size=0.004",
                                facecolor=SIGNAL, edgecolor="none", alpha=0.85))
    ax.add_patch(FancyBboxPatch((0.078, 0.650), 0.115, 0.004,
                                boxstyle="round,pad=0,rounding_size=0.002",
                                facecolor=BLUE, edgecolor="none", alpha=0.72))

    fig.savefig(FIG / "cover_art.png", dpi=dpi, bbox_inches="tight", pad_inches=0)
    plt.close(fig)


def make_endpoint_walk_figure() -> None:
    rng = random.Random(808)
    n, m = 7, 5
    L = n - 1 + 2 * m
    fig, ax = plt.subplots(figsize=(8.4, 4.8))
    ax.set_facecolor(OFF_WHITE)
    x = np.arange(L + 1)
    for t in range(L + 1):
        ax.axvline(t, color=MUTED, lw=0.35, alpha=0.13)
    for y in range(n):
        ax.axhline(y, color=MUTED, lw=0.35, alpha=0.16)
    for idx in range(9):
        w = sample_walk(n, m, rng)
        ax.plot(x, w, lw=1.3, alpha=0.52 if idx else 0.92,
                color=[SIGNAL, TEAL_LIGHT, BLUE, EMERALD][idx % 4])
    ax.scatter([0, L], [0, n - 1], s=70, zorder=5, facecolor=MINT, edgecolor=TEAL, linewidth=1)
    ax.text(0.15, 0.15, r"endpoint $1$", ha="left", va="bottom", fontsize=10)
    ax.text(L, n - 0.45, rf"endpoint ${n}$", ha="center", va="bottom", fontsize=10)
    ax.set_xlim(-0.7, L + 0.7)
    ax.set_ylim(-0.85, n - 0.15)
    ax.set_xlabel(r"walk step $\ell$")
    ax.set_ylabel("path-graph vertex minus one")
    ax.set_title(rf"CHS coefficient as endpoint walks: $n={n}$, $d={2*m}$, length $n-1+d={L}$")
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(FIG / "endpoint_walks.pdf", bbox_inches="tight")
    fig.savefig(FIG / "endpoint_walks.png", dpi=240, bbox_inches="tight")
    plt.close(fig)


def make_reflection_figure() -> None:
    n, m = 6, 4
    N = n + 1
    L = n - 1 + 2 * m
    fig, ax = plt.subplots(figsize=(8.4, 5.1))
    ax.set_facecolor(OFF_WHITE)
    # Image-source locations for the two signed families in the unfolded line.
    js = range(-1, 2)
    pos_sources = [1 + 2 * j * N for j in js]
    neg_sources = [-1 + 2 * j * N for j in js]
    for y in range(-2 * N - 2, 2 * N + n + 3):
        if y % N == 0:
            ax.axhline(y, color=WARNING, lw=0.9, alpha=0.35)
        elif y % N in range(1, n + 1):
            ax.axhline(y, color=MUTED, lw=0.3, alpha=0.08)
    ax.axvspan(0, L, ymin=0.39, ymax=0.61, color=SIGNAL, alpha=0.045)
    for y in pos_sources:
        ax.scatter(0, y, s=58, facecolor=SIGNAL, edgecolor=TEAL, linewidth=0.8, zorder=5)
        ax.text(-0.35, y, "+", color=TEAL, ha="right", va="center", fontsize=11, fontweight="bold")
    for y in neg_sources:
        ax.scatter(0, y, s=52, facecolor=OFF_WHITE, edgecolor=WARNING, linewidth=1.0, zorder=5)
        ax.text(-0.35, y, "-", color=WARNING, ha="right", va="center", fontsize=11, fontweight="bold")
    target = n
    ax.scatter(L, target, s=72, facecolor=MINT, edgecolor=TEAL, linewidth=1.0, zorder=6)
    # Straight guide rays represent unrestricted displacement classes.
    for y in pos_sources:
        ax.plot([0, L], [y, target], color=SIGNAL, lw=0.8, alpha=0.25)
    for y in neg_sources:
        ax.plot([0, L], [y, target], color=WARNING, lw=0.8, alpha=0.20, linestyle="--")
    ax.text(L + 0.35, target, "target", ha="left", va="center", fontsize=10)
    ax.text(L / 2, 0.35, r"physical strip $1\leq v\leq n$", ha="center", va="bottom", color=TEAL, fontsize=10)
    ax.set_xlim(-1.1, L + 1.7)
    ax.set_ylim(-2 * N - 2, 2 * N + n + 2)
    ax.set_xlabel(r"walk length $\ell$")
    ax.set_ylabel("unfolded vertex coordinate")
    ax.set_title("Signed image sources behind the two-barrier reflection formula")
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(FIG / "reflection_images.pdf", bbox_inches="tight")
    fig.savefig(FIG / "reflection_images.png", dpi=240, bbox_inches="tight")
    plt.close(fig)


def reciprocal_values(n: int, max_m: int) -> list[int]:
    den = [(-1) ** r * math.comb(n - r, r) for r in range(n // 2 + 1)]
    a = [0] * (max_m + 1)
    a[0] = 1
    for m in range(1, max_m + 1):
        a[m] = -sum(den[r] * a[m-r] for r in range(1, min(m, len(den)-1)+1))
    return a


def make_growth_figure() -> None:
    fig, ax = plt.subplots(figsize=(8.4, 4.9))
    ax.set_facecolor(OFF_WHITE)
    ms = np.arange(0, 16)
    for n, col in zip([2, 3, 4, 5, 6, 8], [MUTED, BLUE, SIGNAL, TEAL_LIGHT, EMERALD, CHARCOAL]):
        vals = reciprocal_values(n, int(ms[-1]))
        ax.plot(ms, vals, marker="o", markersize=3.3, lw=1.35, label=rf"$P_{n}$", color=col)
    ax.set_yscale("symlog", linthresh=1)
    ax.set_xlabel(r"$m$ in $d=2m$")
    ax.set_ylabel(r"$a_{n,m}=\|P_n\|_{X,2m}^{2m}$")
    ax.set_title("Exact integer CHS powers generated by endpoint walks")
    ax.grid(True, which="both", lw=0.35, alpha=0.18)
    ax.legend(ncol=3, frameon=False)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(FIG / "integer_growth.pdf", bbox_inches="tight")
    fig.savefig(FIG / "integer_growth.png", dpi=240, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    make_cover()
    make_endpoint_walk_figure()
    make_reflection_figure()
    make_growth_figure()
    print(f"Generated figures in {FIG}")


if __name__ == "__main__":
    main()
