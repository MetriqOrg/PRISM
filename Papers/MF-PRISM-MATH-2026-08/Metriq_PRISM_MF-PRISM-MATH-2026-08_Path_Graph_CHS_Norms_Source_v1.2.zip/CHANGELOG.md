# Changelog - MF-PRISM-MATH-2026-08

## Version 1.2 - 18 July 2026

Metriq PRISM Laboratory edition; updated cover and masthead, institutional disclaimer, release metadata, licensing, checksums, and package organization. No mathematical claim was changed.

## Version 1.0 - 15 July 2026

Initial candidate preprint.

## Version 1.2 - 2026-07-18

- Migrated identifier from `MF-MATH-2026-08` to `MF-PRISM-MATH-2026-08`.
- Added candidate-stage contributor, ORCID, correspondence, funding, conflicts, licensing, DOI, and predecessor metadata.
- Softened the boundary correction to a proposed correction pending confirmation and emphasized the endpoint-walk interpretation as the principal contribution.
- Rebuilt and revalidated the PDF and source package.
