# Main Theorem - MF-PRISM-MATH-2026-02

A variable-base block sequence with Q_n=product_(k=1)^n(2k+4) is claimed to generate a Cantorval E with dim_H(boundary E)=1.
