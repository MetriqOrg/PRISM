# Known Risk Points

## Internal risk level

**High**

## Questions requiring adversarial review

1. Is the protected Moran set C genuinely contained in the topological boundary, including endpoint cases?
2. Does the finite-prefix separation estimate hold uniformly at the scale claimed?
3. Is the mass estimate sufficient for all sufficiently small radii, not only selected cylinder scales?
4. Are there earlier variable-radix subsum constructions with full-dimensional boundary?

## Required corrections already identified

- Add a finite-prefix uniqueness and 1/Q_n separation lemma for protected digits.
- Make the boundary-inclusion proof explicit at endpoints and state exactly how nearby complement points are produced at every scale.
- Define the probability measure on the protected cylinders before applying the mass-distribution principle.
- Separate the exact theorem from finite numerical diagnostics; the diagnostics support but do not prove the dimension claim.
- Update publication metadata and the proposed identifier migration.
