# Review guide

# Independent Mathematical Review Guide

## MF-PRISM-MATH-2026-02 - An Achievable Cantorval with Full-Dimensional Boundary

**Version reviewed:** 1.2  
**Issuer:** Metriq PRISM Laboratory, a research laboratory of Metriq Foundation, Inc.  
**Status:** Candidate result; not independently peer reviewed

## Central claim

The candidate construction concatenates blocks scaled by Q_n=2^(n-1)(n+2)! and claims E is a Cantorval with dim_H(partial E)=1.

## Load-bearing review targets

1. Verify the block digit sets and complete residue system modulo b_n=2n+4.
2. Audit the mixed-radix interior argument and the exact tail identity producing one genuine gap at every block scale.
3. Verify parent-cylinder containment and global isolation of the protected lower-even branches.
4. Check the product-measure cylinder masses, separation estimates, and Frostman/mass-distribution proof of dimension one.
5. Search for nonstationary or variable-base constructions equivalent to the proposed example.

## Review format requested

A useful review should identify the exact theorem, lemma, equation, figure, or
page involved; distinguish fatal, repairable, and expository issues; and supply
a counterexample, correction, independent derivation, or prior-art reference
where possible. Computational checks should be reported separately from review
of the infinite argument.

## Scope limitation

A successful reproduction of the included scripts does not establish the
candidate theorem, novelty, or priority. Independent mathematical reading is
required.


## Phase 2 review note

This guide applies to MF-PRISM-MATH-2026-02 Version 1.3. Reviewers should use the standalone reviewer packet and exact versioned PDF.
