# Changelog - MF-PRISM-MATH-2026-02

## Version 1.3 - 18 July 2026

Metriq PRISM Laboratory edition; updated cover and masthead, institutional disclaimer, release metadata, licensing, checksums, and package organization. No mathematical claim was changed.

## Version 1.1 - 15 July 2026

Integrated audited proof revisions: exact tail identity, finite-branch formalization, protected gap endpoints and containment, prefix uniqueness, spacing, and exact product-measure masses.

## Version 1.0 - 15 July 2026

Initial candidate preprint.

## Version 1.3 - 2026-07-18

- Migrated identifier from `MF-MATH-2026-02` to `MF-PRISM-MATH-2026-02`.
- Added candidate-stage contributor, ORCID, correspondence, funding, conflicts, licensing, DOI, and predecessor metadata.
- Added protected-prefix uniqueness and grid-separation details and made the boundary-proximity argument explicit.
- Rebuilt and revalidated the PDF and source package.
