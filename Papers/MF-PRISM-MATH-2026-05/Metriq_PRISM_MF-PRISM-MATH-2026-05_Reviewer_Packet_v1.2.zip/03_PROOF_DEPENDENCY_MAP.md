# Proof Dependency Map

1. **Base-expansion lemma** - Identify digitwise sums for geometric Cantor sets.
2. **Middle-third witness** - Compute r_n and verify fast convergence and the c<3 limit.
3. **Cantor self-sum** - Prove C+C=[0,2] by ternary digit selection.
4. **Sharpness theorem** - Use the interval self-sum to refute every replacement c<3.
5. **m-fold extension** - Generalize to x_n=m/(m+1)^n and mE=[0,m].
