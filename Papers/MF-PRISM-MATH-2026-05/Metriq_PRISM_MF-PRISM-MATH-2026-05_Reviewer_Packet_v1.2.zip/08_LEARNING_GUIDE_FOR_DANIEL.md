# Proof-Learning Guide for Daniel H. Jeffery

The purpose of this guide is to support paper-specific technical review and scholarly accountability. Completion does not replace external review.

## Learning objectives

1. Reproduce r_n=3^(-n) and the c<3 limit.
2. Explain ternary representations of C and give a constructive proof of C+C=[0,2].
3. Distinguish a theorem about the literal printed statement from the intended research question.
4. Read the theorem immediately preceding Problem 13 and identify every quantifier.
5. Prepare to explain why an apparent one-line solution is itself a reason for caution.
6. Do not clear the source-author hold until the intended formulation is settled.

## Technical self-test

Before approving the candidate release, Daniel should be able to answer all of the following without relying on the manuscript's wording:

1. What exactly is being proved?
2. Which definitions are nonstandard or specialized?
3. What is the proof strategy in five minutes?
4. Which lemma is most fragile and why?
5. Which claims are machine-checked and which are not?
6. Which external theorem is imported, and what are its hypotheses?
7. What counterexample would break the proof if a key assumption were removed?
8. What would require correction or withdrawal?
