# Known Risk Points

## Internal risk level

**Moderate**

## Questions requiring adversarial review

1. Does the complete-residue/Baire argument contain any hidden assumption about the finite translates?
2. Is the classification theorem quoted in precisely the form needed here?
3. Is this construction equivalent to an earlier multigeometric or variable-digit construction?
4. Does the proposed sequence answer the intended Second Jones Problem rather than a narrower formulation?

## Required corrections already identified

- Replace the phrase “fourth nonfinite topological type” with a precise description such as “remaining topological alternative in the achievement-set classification.”
- Add a direct bibliographic trail for the Jones attribution and verify that the survey statement matches the intended problem.
- State the exact classification theorem and cite the corrected proof used in the final step.
- Update identifier, author/contributor metadata, correspondence address, website, version, DOI placeholder, and preferred citation.
