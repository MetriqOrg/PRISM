# Main Theorem - MF-PRISM-MATH-2026-01

For x_(2n-1)=(8n+17)/4^n and x_(2n)=(4n+18)/4^n, the sequence is positive, strictly decreasing, sums to 17, has x_(k+1)/x_k -> 1/2, and has a Cantorval achievement set.
