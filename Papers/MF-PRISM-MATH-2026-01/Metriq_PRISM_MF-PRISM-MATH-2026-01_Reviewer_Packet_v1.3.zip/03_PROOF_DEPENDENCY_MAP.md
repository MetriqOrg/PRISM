# Proof Dependency Map

1. **Lemma 4.1 / elementary properties** - Establish positivity, strict decrease, and total sum 17.
2. **Proposition 4.2 / ratio limit** - Show both adjacent-ratio subsequences converge to 1/2.
3. **Mixed-radix residue lemma** - Show the paired digit sets form complete residue systems modulo 4^N.
4. **Interior proposition** - Use dense base-4 grids, compactness, and the Baire category argument to force nonempty interior.
5. **Tail identity and gap proposition** - Compute r_(2n) exactly and prove (r_(2n),x_(2n)) is a genuine gap at every scale.
6. **Classification consequence** - Use nonempty interior and infinitely many gaps to select the Cantorval alternative.
