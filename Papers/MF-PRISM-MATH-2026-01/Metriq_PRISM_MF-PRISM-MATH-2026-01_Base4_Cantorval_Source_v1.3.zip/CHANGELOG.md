# Changelog - MF-PRISM-MATH-2026-01

## Version 1.3 - 18 July 2026

Metriq PRISM Laboratory edition; updated cover and masthead, institutional disclaimer, release metadata, licensing, checksums, and package organization. No mathematical claim was changed.

## Version 1.1 - 15 July 2026

Integrated audited proof revisions: explicit compactness and Baire-category step, corrected classification citation, exact tail/gap presentation, and tightened priority language.

## Version 1.0 - 15 July 2026

Initial candidate preprint.

## Version 1.3 - 2026-07-18

- Migrated identifier from `MF-MATH-2026-01` to `MF-PRISM-MATH-2026-01`.
- Added candidate-stage contributor, ORCID, correspondence, funding, conflicts, licensing, DOI, and predecessor metadata.
- Clarified the exact achievement-set classification language and added complete candidate-stage publication metadata.
- Rebuilt and revalidated the PDF and source package.
